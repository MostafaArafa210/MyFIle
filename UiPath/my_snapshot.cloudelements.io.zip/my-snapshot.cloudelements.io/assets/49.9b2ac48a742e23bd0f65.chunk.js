(window.webpackJsonp = window.webpackJsonp || []).push([
    [49], {
        "5a3108d76cb6a1a160dc": function(t, e, n) {
            "use strict";
            n.r(e);
            var r = n("d7c625d1f2819028b697");

            function i(t) {
                var e = {};
                return Object.keys(t).forEach((function(n) {
                    var r;
                    e[(r = n, r.replace(/[A-Z]/g, (function(t, e) {
                        return (0 !== e ? "_" : "") + t.toLowerCase()
                    })).replace(/-/g, "_"))] = function t(e) {
                        if (Array.isArray(e)) return e.map((function(e) {
                            return t(e)
                        }));
                        if ("object" == typeof e && null !== e) return i(e);
                        return e
                    }(t[n])
                })), e
            }
            var o, a = function(t) {
                    return Array.isArray(t)
                },
                u = function(t) {
                    return !Array.isArray(t) && "object" == typeof t && null !== t
                };

            function s() {
                for (var t, e = [], n = 0; n < arguments.length; n++) e[n] = arguments[n];
                for (var r = 0, i = e; r < i.length; r++) {
                    var o = i[r];
                    null != o && (t = d(t, o, f()))
                }
                return t
            }

            function c(t) {
                return d(void 0, t, f())
            }

            function f() {
                if ("undefined" != typeof WeakSet) {
                    var t = new WeakSet;
                    return {
                        hasAlreadyBeenSeen: function(e) {
                            var n = t.has(e);
                            return n || t.add(e), n
                        }
                    }
                }
                var e = [];
                return {
                    hasAlreadyBeenSeen: function(t) {
                        var n = e.indexOf(t) >= 0;
                        return n || e.push(t), n
                    }
                }
            }

            function d(t, e, n) {
                if (void 0 === e) return t;
                if (!u(e) && !a(e)) return e;
                if (!n.hasAlreadyBeenSeen(e)) {
                    if (u(e) && (void 0 === t || u(t))) {
                        var r = t || {};
                        for (var i in e) Object.prototype.hasOwnProperty.call(e, i) && (r[i] = d(r[i], e[i], n));
                        return r
                    }
                    if (a(e) && (void 0 === t || a(t))) {
                        (r = t || []).length = Math.max(r.length, e.length);
                        for (var o = 0; o < e.length; o += 1) r[o] = d(r[o], e[o], n);
                        return r
                    }
                    return e
                }
            }

            function l(t, e, n) {
                return t && (void 0 !== t.message || e instanceof Error) ? {
                    message: t.message || "Empty message",
                    stack: p(t),
                    type: t.name
                } : {
                    message: n + " " + j(e),
                    stack: "No stack, consider using an instance of Error",
                    type: t && t.name
                }
            }

            function p(t) {
                var e = (t.name || "Error") + ": " + t.message;
                return t.stack.forEach((function(t) {
                    var n = "?" === t.func ? "<anonymous>" : t.func,
                        r = t.args && t.args.length > 0 ? "(" + t.args.join(", ") + ")" : "",
                        i = t.line ? ":" + t.line : "",
                        o = t.line && t.column ? ":" + t.column : "";
                    e += "\n  at " + n + r + " @ " + t.url + i + o
                })), e
            }! function(t) {
                t.AGENT = "agent", t.CONSOLE = "console", t.NETWORK = "network", t.SOURCE = "source", t.LOGGER = "logger", t.CUSTOM = "custom"
            }(o || (o = {}));
            var E = /[^\u0000-\u007F]/,
                m = function() {
                    function t(t, e, n) {
                        void 0 === n && (n = !1), this.endpointUrl = t, this.bytesLimit = e, this.withBatchTime = n
                    }
                    return t.prototype.send = function(t, e) {
                        var n = this.withBatchTime ? function(t) {
                            return t + (-1 === t.indexOf("?") ? "?" : "&") + "batch_time=" + (new Date).getTime()
                        }(this.endpointUrl) : this.endpointUrl;
                        if (navigator.sendBeacon && e < this.bytesLimit && navigator.sendBeacon(n, t)) return;
                        var r = new XMLHttpRequest;
                        r.open("POST", n, !0), r.send(t)
                    }, t
                }();
            var v = function() {
                    function t(t, e, n, r, i, o) {
                        void 0 === o && (o = W), this.request = t, this.maxSize = e, this.bytesLimit = n, this.maxMessageSize = r, this.flushTimeout = i, this.beforeUnloadCallback = o, this.pushOnlyBuffer = [], this.upsertBuffer = {}, this.bufferBytesSize = 0, this.bufferMessageCount = 0, this.flushOnVisibilityHidden(), this.flushPeriodically()
                    }
                    return t.prototype.add = function(t) {
                        this.addOrUpdate(t)
                    }, t.prototype.upsert = function(t, e) {
                        this.addOrUpdate(t, e)
                    }, t.prototype.flush = function() {
                        if (0 !== this.bufferMessageCount) {
                            var t = Object(r.f)(this.pushOnlyBuffer, (e = this.upsertBuffer, n = [], Object.keys(e).forEach((function(t) {
                                n.push(e[t])
                            })), n));
                            this.request.send(t.join("\n"), this.bufferBytesSize), this.pushOnlyBuffer = [], this.upsertBuffer = {}, this.bufferBytesSize = 0, this.bufferMessageCount = 0
                        }
                        var e, n
                    }, t.prototype.sizeInBytes = function(t) {
                        return E.test(t) ? void 0 !== window.TextEncoder ? (new TextEncoder).encode(t).length : new Blob([t]).size : t.length
                    }, t.prototype.addOrUpdate = function(t, e) {
                        var n = this.process(t),
                            r = n.processedMessage,
                            i = n.messageBytesSize;
                        i >= this.maxMessageSize ? console.warn("Discarded a message whose size was bigger than the maximum allowed size " + this.maxMessageSize + "KB.") : (this.hasMessageFor(e) && this.remove(e), this.willReachedBytesLimitWith(i) && this.flush(), this.push(r, i, e), this.isFull() && this.flush())
                    }, t.prototype.process = function(t) {
                        var e = j(t);
                        return {
                            processedMessage: e,
                            messageBytesSize: this.sizeInBytes(e)
                        }
                    }, t.prototype.push = function(t, e, n) {
                        this.bufferMessageCount > 0 && (this.bufferBytesSize += 1), void 0 !== n ? this.upsertBuffer[n] = t : this.pushOnlyBuffer.push(t), this.bufferBytesSize += e, this.bufferMessageCount += 1
                    }, t.prototype.remove = function(t) {
                        var e = this.upsertBuffer[t];
                        delete this.upsertBuffer[t];
                        var n = this.sizeInBytes(e);
                        this.bufferBytesSize -= n, this.bufferMessageCount -= 1, this.bufferMessageCount > 0 && (this.bufferBytesSize -= 1)
                    }, t.prototype.hasMessageFor = function(t) {
                        return void 0 !== t && void 0 !== this.upsertBuffer[t]
                    }, t.prototype.willReachedBytesLimitWith = function(t) {
                        return this.bufferBytesSize + t + 1 >= this.bytesLimit
                    }, t.prototype.isFull = function() {
                        return this.bufferMessageCount === this.maxSize || this.bufferBytesSize >= this.bytesLimit
                    }, t.prototype.flushPeriodically = function() {
                        var t = this;
                        setTimeout((function() {
                            t.flush(), t.flushPeriodically()
                        }), this.flushTimeout)
                    }, t.prototype.flushOnVisibilityHidden = function() {
                        var t = this;
                        navigator.sendBeacon && (X(window, L.BEFORE_UNLOAD, this.beforeUnloadCallback), X(document, L.VISIBILITY_CHANGE, (function() {
                            "hidden" === document.visibilityState && t.flush()
                        })), X(window, L.BEFORE_UNLOAD, (function() {
                            return t.flush()
                        })))
                    }, t
                }(),
                T = /^(?:[Uu]ncaught (?:exception: )?)?(?:((?:Eval|Internal|Range|Reference|Syntax|Type|URI|)Error): )?(.*)$/;

            function h(t, e) {
                return Object.prototype.hasOwnProperty.call(t, e)
            }
            var g, b = function() {
                    var t, e, n, r, i, o, a = [];

                    function u(t, e, n) {
                        var r;
                        for (var i in a)
                            if (h(a, i)) try {
                                a[i](t, e, n)
                            } catch (t) {
                                r = t
                            }
                        if (r) throw r
                    }

                    function s(t, r, i, o, a) {
                        if (e) y.augmentStackTraceWithInitialElement(e, r, i, "" + t), f();
                        else if (a) u(y(a), !0, a);
                        else {
                            var s, c = {
                                    url: r,
                                    column: o,
                                    line: i
                                },
                                d = t;
                            if ("[object String]" === {}.toString.call(t)) {
                                var l = d.match(T);
                                l && (s = l[1], d = l[2])
                            }
                            u({
                                name: s,
                                message: d,
                                stack: [c]
                            }, !0)
                        }
                        return !!n && n.apply(this, arguments)
                    }

                    function c(t) {
                        var e = t.reason || "Empty reason";
                        u(y(e), !0, e)
                    }

                    function f() {
                        var n = e,
                            r = t;
                        e = void 0, t = void 0, u(n, !1, r)
                    }

                    function d(n) {
                        if (e) {
                            if (t === n) return;
                            f()
                        }
                        var r = y(n);
                        throw e = r, t = n, setTimeout((function() {
                            t === n && f()
                        }), r.incomplete ? 2e3 : 0), n
                    }
                    return d.subscribe = function(t) {
                        ! function() {
                            if (r) return;
                            n = window.onerror, window.onerror = _(s), r = !0
                        }(),
                        function() {
                            if (o) return;
                            i = null !== window.onunhandledrejection ? window.onunhandledrejection : void 0, window.onunhandledrejection = _(c), o = !0
                        }(), a.push(t)
                    }, d.unsubscribe = function(t) {
                        for (var e = a.length - 1; e >= 0; e -= 1) a[e] === t && a.splice(e, 1);
                        0 === a.length && (r && (window.onerror = n, r = !1), o && (window.onunhandledrejection = i, o = !1))
                    }, d.traceKitWindowOnError = s, d
                }(),
                y = function() {
                    function t(t) {
                        if (t.stack) {
                            for (var e, n, r, i, o = /^\s*at (.*?) ?\(((?:file|https?|blob|chrome-extension|native|eval|webpack|<anonymous>|\/).*?)(?::(\d+))?(?::(\d+))?\)?\s*$/i, a = /^\s*(.*?)(?:\((.*?)\))?(?:^|@)((?:file|https?|blob|chrome|webpack|resource|\[native).*?|[^@]*bundle)(?::(\d+))?(?::(\d+))?\s*$/i, u = /^\s*at (?:((?:\[object object\])?.+) )?\(?((?:file|ms-appx|https?|webpack|blob):.*?):(\d+)(?::(\d+))?\)?\s*$/i, s = /(\S+) line (\d+)(?: > eval line \d+)* > eval/i, c = /\((\S*)(?::(\d+))(?::(\d+))\)/, f = t.stack.split("\n"), d = [], l = 0, p = f.length; l < p; l += 1) {
                                if (o.exec(f[l])) {
                                    var E = (r = o.exec(f[l]))[2] && 0 === r[2].indexOf("native");
                                    e = r[2] && 0 === r[2].indexOf("eval"), n = c.exec(r[2]), e && n && (r[2] = n[1], r[3] = n[2], r[4] = n[3]), i = {
                                        args: E ? [r[2]] : [],
                                        column: r[4] ? +r[4] : void 0,
                                        func: r[1] || "?",
                                        line: r[3] ? +r[3] : void 0,
                                        url: E ? void 0 : r[2]
                                    }
                                } else if (u.exec(f[l])) i = {
                                    args: [],
                                    column: (r = u.exec(f[l]))[4] ? +r[4] : void 0,
                                    func: r[1] || "?",
                                    line: +r[3],
                                    url: r[2]
                                };
                                else {
                                    if (!a.exec(f[l])) continue;
                                    e = (r = a.exec(f[l]))[3] && r[3].indexOf(" > eval") > -1, n = s.exec(r[3]), e && n ? (r[3] = n[1], r[4] = n[2], r[5] = void 0) : 0 !== l || r[5] || void 0 === t.columnNumber || (d[0].column = t.columnNumber + 1), i = {
                                        args: r[2] ? r[2].split(",") : [],
                                        column: r[5] ? +r[5] : void 0,
                                        func: r[1] || "?",
                                        line: r[4] ? +r[4] : void 0,
                                        url: r[3]
                                    }
                                }!i.func && i.line && (i.func = "?"), d.push(i)
                            }
                            if (d.length) return {
                                stack: d,
                                message: t.message,
                                name: t.name
                            }
                        }
                    }

                    function e(t, e, n, r) {
                        var i = {
                            url: e,
                            line: n ? +n : void 0
                        };
                        if (i.url && i.line) {
                            t.incomplete = !1;
                            var o = t.stack;
                            if (o.length > 0 && o[0].url === i.url) {
                                if (o[0].line === i.line) return !1;
                                if (!o[0].line && o[0].func === i.func) return o[0].line = i.line, o[0].context = i.context, !1
                            }
                            return o.unshift(i), t.partial = !0, !0
                        }
                        return t.incomplete = !0, !1
                    }

                    function n(t, r) {
                        for (var i, o, a = /function\s+([_$a-zA-Z\xA0-\uFFFF][_$a-zA-Z0-9\xA0-\uFFFF]*)?\s*\(/i, u = [], s = {}, c = !1, f = n.caller; f && !c; f = f.caller) f !== y && f !== b && (o = {
                            args: [],
                            column: void 0,
                            func: "?",
                            line: void 0,
                            url: void 0
                        }, i = a.exec(f.toString()), f.name ? o.func = f.name : i && (o.func = i[1]), void 0 === o.func && (o.func = i ? i.input.substring(0, i.input.indexOf("{")) : void 0), s["" + f] ? c = !0 : s["" + f] = !0, u.push(o));
                        r && u.splice(0, r);
                        var d = {
                            stack: u,
                            message: t.message,
                            name: t.name
                        };
                        return e(d, t.sourceURL || t.fileName, t.line || t.lineNumber, t.message || t.description), d
                    }

                    function r(e, r) {
                        var i, o = void 0 === r ? 0 : +r;
                        try {
                            if (i = function(t) {
                                    var e = t.stacktrace;
                                    if (e) {
                                        for (var n, r = / line (\d+).*script (?:in )?(\S+)(?:: in function (\S+))?$/i, i = / line (\d+), column (\d+)\s*(?:in (?:<anonymous function: ([^>]+)>|([^\)]+))\((.*)\))? in (.*):\s*$/i, o = e.split("\n"), a = [], u = 0; u < o.length; u += 2) {
                                            var s = void 0;
                                            r.exec(o[u]) ? s = {
                                                args: [],
                                                column: void 0,
                                                func: (n = r.exec(o[u]))[3],
                                                line: +n[1],
                                                url: n[2]
                                            } : i.exec(o[u]) && (s = {
                                                args: (n = i.exec(o[u]))[5] ? n[5].split(",") : [],
                                                column: +n[2],
                                                func: n[3] || n[4],
                                                line: +n[1],
                                                url: n[6]
                                            }), s && (!s.func && s.line && (s.func = "?"), s.context = [o[u + 1]], a.push(s))
                                        }
                                        if (a.length) return {
                                            stack: a,
                                            message: t.message,
                                            name: t.name
                                        }
                                    }
                                }(e)) return i
                        } catch (t) {
                            0
                        }
                        try {
                            if (i = t(e)) return i
                        } catch (t) {
                            0
                        }
                        try {
                            if (i = function(t) {
                                    var e = t.message.split("\n");
                                    if (!(e.length < 4)) {
                                        var n, r = /^\s*Line (\d+) of linked script ((?:file|https?|blob)\S+)(?:: in function (\S+))?\s*$/i,
                                            i = /^\s*Line (\d+) of inline#(\d+) script in ((?:file|https?|blob)\S+)(?:: in function (\S+))?\s*$/i,
                                            o = /^\s*Line (\d+) of function script\s*$/i,
                                            a = [],
                                            u = window && window.document && window.document.getElementsByTagName("script"),
                                            s = [];
                                        for (var c in u) h(u, c) && !u[c].src && s.push(u[c]);
                                        for (var f = 2; f < e.length; f += 2) {
                                            var d = void 0;
                                            if (r.exec(e[f])) d = {
                                                args: [],
                                                column: void 0,
                                                func: (n = r.exec(e[f]))[3],
                                                line: +n[1],
                                                url: n[2]
                                            };
                                            else if (i.exec(e[f])) d = {
                                                args: [],
                                                column: void 0,
                                                func: (n = i.exec(e[f]))[4],
                                                line: +n[1],
                                                url: n[3]
                                            };
                                            else if (o.exec(e[f])) {
                                                n = o.exec(e[f]), d = {
                                                    url: window.location.href.replace(/#.*$/, ""),
                                                    args: [],
                                                    column: void 0,
                                                    func: "",
                                                    line: +n[1]
                                                }
                                            }
                                            d && (d.func || (d.func = "?"), d.context = [e[f + 1]], a.push(d))
                                        }
                                        if (a.length) return {
                                            stack: a,
                                            message: e[0],
                                            name: t.name
                                        }
                                    }
                                }(e)) return i
                        } catch (t) {
                            0
                        }
                        try {
                            if (i = n(e, o + 1)) return i
                        } catch (t) {
                            0
                        }
                        return {
                            message: e.message,
                            name: e.name,
                            stack: []
                        }
                    }
                    return r.augmentStackTraceWithInitialElement = e, r.computeStackTraceFromStackProp = t, r.ofCaller = function(t) {
                        var e = 1 + (void 0 === t ? 0 : +t);
                        try {
                            throw new Error
                        } catch (t) {
                            return y(t, e + 1)
                        }
                    }, r
                }();
            ! function(t) {
                t.info = "info", t.error = "error"
            }(g || (g = {}));
            var C, O = {
                maxMessagesPerPage: 0,
                sentMessageCount: 0
            };

            function R(t) {
                if (t.internalMonitoringEndpoint) {
                    var e = function(t) {
                        var e, n = r(t.internalMonitoringEndpoint);
                        void 0 !== t.replica && (e = r(t.replica.internalMonitoringEndpoint));

                        function r(e) {
                            return new v(new m(e, t.batchBytesLimit), t.maxBatchSize, t.batchBytesLimit, t.maxMessageSize, t.flushTimeout)
                        }
                        return {
                            add: function(t) {
                                var r = function(t) {
                                    return s({
                                        date: (new Date).getTime(),
                                        view: {
                                            referrer: document.referrer,
                                            url: window.location.href
                                        }
                                    }, void 0 !== C ? C() : {}, t)
                                }(t);
                                n.add(r), e && e.add(r)
                            }
                        }
                    }(t);
                    ! function(t) {
                        for (var e = [], n = 1; n < arguments.length; n++) e[n - 1] = arguments[n];
                        e.forEach((function(e) {
                            for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n])
                        }))
                    }(O, {
                        batch: e,
                        maxMessagesPerPage: t.maxInternalMonitoringMessagesPerPage,
                        sentMessageCount: 0
                    })
                }
                return {
                    setExternalContextProvider: function(t) {
                        C = t
                    }
                }
            }

            function _(t) {
                return function() {
                    try {
                        return t.apply(this, arguments)
                    } catch (t) {
                        N(t);
                        try {
                            w(t)
                        } catch (t) {
                            N(t)
                        }
                    }
                }
            }

            function S(t, e) {
                ! function(t) {
                    O.debugMode && console.log("[MONITORING MESSAGE]", t)
                }(t), A(Object(r.a)(Object(r.a)({
                    message: t
                }, e), {
                    status: g.info
                }))
            }

            function w(t) {
                A(Object(r.a)(Object(r.a)({}, function(t) {
                    if (t instanceof Error) {
                        var e = y(t);
                        return {
                            error: {
                                kind: e.name,
                                stack: p(e)
                            },
                            message: e.message
                        }
                    }
                    return {
                        error: {
                            stack: "Not an instance of error"
                        },
                        message: "Uncaught " + j(t)
                    }
                }(t)), {
                    status: g.error
                }))
            }

            function A(t) {
                O.batch && O.sentMessageCount < O.maxMessagesPerPage && (O.sentMessageCount += 1, O.batch.add(t))
            }

            function I(t) {
                O.debugMode = t
            }

            function N(t) {
                O.debugMode && console.warn("[INTERNAL ERROR]", t)
            }
            var L, D, U, M;

            function x(t, e, n) {
                var r, i = !n || void 0 === n.leading || n.leading,
                    o = !n || void 0 === n.trailing || n.trailing,
                    a = !1,
                    u = !1;
                return {
                    throttled: function() {
                        var n = this;
                        a ? u = !0 : (i ? t.apply(this) : u = !0, a = !0, r = window.setTimeout((function() {
                            o && u && t.apply(n), a = !1, u = !1
                        }), e))
                    },
                    cancel: function() {
                        window.clearTimeout(r), a = !1, u = !1
                    }
                }
            }

            function k(t) {
                return t ? (parseInt(t, 10) ^ 16 * Math.random() >> parseInt(t, 10) / 4).toString(16) : "10000000-1000-4000-8000-100000000000".replace(/[018]/g, k)
            }

            function V(t) {
                return 0 !== t && 100 * Math.random() <= t
            }

            function P(t) {
                return "number" != typeof t ? t : +(1e6 * t).toFixed(0)
            }

            function W() {}

            function j(t, e, n) {
                if (null == t) return JSON.stringify(t);
                var r = [!1, void 0];
                B(t) && (r = [!0, t.toJSON], delete t.toJSON);
                var i, o, a = [!1, void 0];
                "object" == typeof t && B(i = Object.getPrototypeOf(t)) && (a = [!0, i.toJSON], delete i.toJSON);
                try {
                    o = JSON.stringify(t, void 0, n)
                } catch (t) {
                    o = "<error: unable to serialize object>"
                } finally {
                    r[0] && (t.toJSON = r[1]), a[0] && (i.toJSON = a[1])
                }
                return o
            }

            function B(t) {
                return "object" == typeof t && null !== t && t.hasOwnProperty("toJSON")
            }

            function H(t, e) {
                return -1 !== t.indexOf(e)
            }

            function F(t) {
                return G(t) && t >= 0 && t <= 100
            }

            function G(t) {
                return "number" == typeof t
            }

            function q(t) {
                return Math.floor(K() + t)
            }

            function K() {
                return void 0 === M && (M = performance.timing.navigationStart), M
            }

            function z(t) {
                return Object.keys(t).map((function(e) {
                    return [e, t[e]]
                }))
            }

            function Y(t) {
                if (t.origin) return t.origin;
                var e = t.host.replace(/(:80|:443)$/, "");
                return t.protocol + "//" + e
            }

            function $(t, e) {
                var n = t.match("(?:^|;)\\s*" + e + "\\s*=\\s*([^;]+)");
                return n ? n[1] : void 0
            }

            function X(t, e, n, r) {
                return J(t, [e], n, r)
            }

            function J(t, e, n, r) {
                var i = void 0 === r ? {} : r,
                    o = i.once,
                    a = i.capture,
                    u = i.passive,
                    s = _(o ? function(t) {
                        f(), n(t)
                    } : n),
                    c = u ? {
                        capture: a,
                        passive: u
                    } : a;
                e.forEach((function(e) {
                    return t.addEventListener(e, s, c)
                }));
                var f = function() {
                    return e.forEach((function(e) {
                        return t.removeEventListener(e, s, c)
                    }))
                };
                return {
                    stop: f
                }
            }! function(t) {
                t.BEFORE_UNLOAD = "beforeunload", t.CLICK = "click", t.KEY_DOWN = "keydown", t.LOAD = "load", t.POP_STATE = "popstate", t.SCROLL = "scroll", t.TOUCH_START = "touchstart", t.VISIBILITY_CHANGE = "visibilitychange", t.DOM_CONTENT_LOADED = "DOMContentLoaded", t.POINTER_DOWN = "pointerdown", t.POINTER_UP = "pointerup", t.POINTER_CANCEL = "pointercancel", t.HASH_CHANGE = "hashchange", t.PAGE_HIDE = "pagehide", t.MOUSE_DOWN = "mousedown"
            }(L || (L = {})),
            function(t) {
                t.DOCUMENT = "document", t.XHR = "xhr", t.BEACON = "beacon", t.FETCH = "fetch", t.CSS = "css", t.JS = "js", t.IMAGE = "image", t.FONT = "font", t.MEDIA = "media", t.OTHER = "other"
            }(D || (D = {})),
            function(t) {
                t.FETCH = "fetch", t.XHR = "xhr"
            }(U || (U = {}));
            var Q;

            function Z(t, e, n, r) {
                var i = new Date;
                i.setTime(i.getTime() + n);
                var o = "expires=" + i.toUTCString(),
                    a = r && r.crossSite ? "none" : "strict",
                    u = r && r.domain ? ";domain=" + r.domain : "",
                    s = r && r.secure ? ";secure" : "";
                document.cookie = t + "=" + e + ";" + o + ";path=/;samesite=" + a + u + s
            }

            function tt(t) {
                return $(document.cookie, t)
            }
            var et, nt, rt = {
                    allowedTracingOrigins: [],
                    maxErrorsByMinute: 3e3,
                    maxInternalMonitoringMessagesPerPage: 15,
                    resourceSampleRate: 100,
                    sampleRate: 100,
                    silentMultipleInit: !1,
                    trackInteractions: !1,
                    requestErrorResponseLengthLimit: 32768,
                    flushTimeout: 3e4,
                    maxBatchSize: 50,
                    maxMessageSize: 262144,
                    batchBytesLimit: 16384
                },
                it = {
                    alternate: {
                        logs: "logs",
                        rum: "rum",
                        trace: "trace"
                    },
                    classic: {
                        logs: "browser",
                        rum: "rum",
                        trace: "public-trace"
                    }
                };

            function ot(t, e) {
                var n = {
                        applicationId: t.applicationId,
                        buildMode: e.buildMode,
                        clientToken: t.clientToken,
                        env: t.env,
                        proxyHost: t.proxyHost,
                        sdkVersion: e.sdkVersion,
                        service: t.service,
                        site: t.site || ft[t.datacenter || e.datacenter],
                        version: t.version
                    },
                    i = Array.isArray(t.enableExperimentalFeatures) ? t.enableExperimentalFeatures : [],
                    o = t.useAlternateIntakeDomains ? "alternate" : "classic",
                    a = function(t, e, n) {
                        if (e.proxyHost) return ["https://" + e.proxyHost + "/v1/input/"];
                        var r = [e.site];
                        e.buildMode === ct.STAGING && n && r.push(ft[nt.US]);
                        for (var i = [], o = Object.keys(it[t]), a = 0, u = r; a < u.length; a++)
                            for (var s = u[a], c = 0, f = o; c < f.length; c++) {
                                var d = f[c];
                                i.push("https://" + st(t, d, s) + "/v1/input/")
                            }
                        return i
                    }(o, n, void 0 !== t.replica),
                    u = Object(r.a)({
                        cookieOptions: at(t),
                        isEnabled: function(t) {
                            return H(i, t)
                        },
                        logsEndpoint: ut(o, "logs", n),
                        proxyHost: t.proxyHost,
                        rumEndpoint: ut(o, "rum", n),
                        service: t.service,
                        traceEndpoint: ut(o, "trace", n),
                        isIntakeUrl: function(t) {
                            return a.some((function(e) {
                                return 0 === t.indexOf(e)
                            }))
                        }
                    }, rt);
                if (t.internalMonitoringApiKey && (u.internalMonitoringEndpoint = ut(o, "logs", n, "browser-agent-internal-monitoring")), "allowedTracingOrigins" in t && (u.allowedTracingOrigins = t.allowedTracingOrigins), "sampleRate" in t && (u.sampleRate = t.sampleRate), "resourceSampleRate" in t && (u.resourceSampleRate = t.resourceSampleRate), "trackInteractions" in t && (u.trackInteractions = !!t.trackInteractions), n.buildMode === ct.E2E_TEST && (u.internalMonitoringEndpoint = "<<< E2E INTERNAL MONITORING ENDPOINT >>>", u.logsEndpoint = "<<< E2E LOGS ENDPOINT >>>", u.rumEndpoint = "<<< E2E RUM ENDPOINT >>>"), n.buildMode === ct.STAGING && void 0 !== t.replica) {
                    var s = Object(r.a)(Object(r.a)({}, n), {
                        applicationId: t.replica.applicationId,
                        clientToken: t.replica.clientToken,
                        site: ft[nt.US]
                    });
                    u.replica = {
                        applicationId: t.replica.applicationId,
                        internalMonitoringEndpoint: ut(o, "logs", s, "browser-agent-internal-monitoring"),
                        logsEndpoint: ut(o, "logs", s),
                        rumEndpoint: ut(o, "rum", s)
                    }
                }
                return u
            }

            function at(t) {
                var e = {};
                return e.secure = function(t) {
                    return !!t.useSecureSessionCookie || !!t.useCrossSiteSessionCookie
                }(t), e.crossSite = !!t.useCrossSiteSessionCookie, t.trackSessionAcrossSubdomains && (e.domain = function() {
                    if (void 0 === Q) {
                        for (var t = "dd_site_test_" + k(), e = window.location.hostname.split("."), n = e.pop(); e.length && !tt(t);) Z(t, "test", 1e3, {
                            domain: n = e.pop() + "." + n
                        });
                        Q = n
                    }
                    return Q
                }()), e
            }

            function ut(t, e, n, r) {
                var i = "sdk_version:" + n.sdkVersion + (n.env ? ",env:" + n.env : "") + (n.service ? ",service:" + n.service : "") + (n.version ? ",version:" + n.version : ""),
                    o = st(t, e, n.site),
                    a = n.proxyHost ? n.proxyHost : o,
                    u = n.proxyHost ? "ddhost=" + o + "&" : "",
                    s = "" + (n.applicationId ? "_dd.application_id=" + n.applicationId + "&" : "") + u + "ddsource=" + (r || "browser") + "&ddtags=" + i;
                return "https://" + a + "/v1/input/" + n.clientToken + "?" + s
            }

            function st(t, e, n) {
                var r = it[t][e];
                if ("classic" === t) return r + "-http-intake.logs." + n;
                var i = n.split("."),
                    o = i.pop();
                return r + ".browser-intake-" + (i.join("-") + "." + o)
            }! function(t) {
                t.US = "us", t.EU = "eu"
            }(nt || (nt = {}));
            var ct, ft = ((et = {})[nt.EU] = "datadoghq.eu", et[nt.US] = "datadoghq.com", et);

            function dt(t) {
                return !! function(t) {
                    if (void 0 === document.cookie || null === document.cookie) return !1;
                    try {
                        var e = "dd_cookie_test_" + k();
                        return Z(e, "test", 1e3, t), "test" === tt(e)
                    } catch (t) {
                        return console.error(t), !1
                    }
                }(t) || (console.warn("Cookies are not authorized, we will not send any data."), !1)
            }

            function lt() {
                return "file:" !== window.location.protocol || (console.error("Execution is not allowed in the current context."), !1)
            }! function(t) {
                t.RELEASE = "release", t.STAGING = "staging", t.E2E_TEST = "e2e-test"
            }(ct || (ct = {}));
            var pt, Et = function() {
                function t(t) {
                    void 0 === t && (t = 1e4), this.limit = t, this.buffer = []
                }
                return t.prototype.add = function(t) {
                    this.buffer.push(t) > this.limit && this.buffer.splice(0, 1)
                }, t.prototype.drain = function(t) {
                    this.buffer.forEach((function(e) {
                        return t(e)
                    })), this.buffer.length = 0
                }, t
            }();
            ! function(t) {
                t[t.PERFORMANCE_ENTRY_COLLECTED = 0] = "PERFORMANCE_ENTRY_COLLECTED", t[t.AUTO_ACTION_CREATED = 1] = "AUTO_ACTION_CREATED", t[t.AUTO_ACTION_COMPLETED = 2] = "AUTO_ACTION_COMPLETED", t[t.AUTO_ACTION_DISCARDED = 3] = "AUTO_ACTION_DISCARDED", t[t.VIEW_CREATED = 4] = "VIEW_CREATED", t[t.VIEW_UPDATED = 5] = "VIEW_UPDATED", t[t.REQUEST_STARTED = 6] = "REQUEST_STARTED", t[t.REQUEST_COMPLETED = 7] = "REQUEST_COMPLETED", t[t.SESSION_RENEWED = 8] = "SESSION_RENEWED", t[t.DOM_MUTATED = 9] = "DOM_MUTATED", t[t.BEFORE_UNLOAD = 10] = "BEFORE_UNLOAD", t[t.RAW_RUM_EVENT_COLLECTED = 11] = "RAW_RUM_EVENT_COLLECTED", t[t.RAW_RUM_EVENT_V2_COLLECTED = 12] = "RAW_RUM_EVENT_V2_COLLECTED", t[t.RUM_EVENT_COLLECTED = 13] = "RUM_EVENT_COLLECTED", t[t.RUM_EVENT_V2_COLLECTED = 14] = "RUM_EVENT_V2_COLLECTED"
            }(pt || (pt = {}));
            var mt, vt, Tt = function() {
                function t() {
                    this.callbacks = {}
                }
                return t.prototype.notify = function(t, e) {
                    var n = this.callbacks[t];
                    n && n.forEach((function(t) {
                        return t(e)
                    }))
                }, t.prototype.subscribe = function(t, e) {
                    var n = this;
                    return this.callbacks[t] || (this.callbacks[t] = []), this.callbacks[t].push(e), {
                        unsubscribe: function() {
                            n.callbacks[t] = n.callbacks[t].filter((function(t) {
                                return e !== t
                            }))
                        }
                    }
                }, t
            }();

            function ht(t, e) {
                void 0 === e && (e = W);
                var n = {
                        errorCount: 0,
                        longTaskCount: 0,
                        resourceCount: 0,
                        userActionCount: 0
                    },
                    r = t.subscribe(pt.RAW_RUM_EVENT_COLLECTED, (function(t) {
                        switch (t.rawRumEvent.evt.category) {
                            case mt.ERROR:
                                n.errorCount += 1, e(n);
                                break;
                            case mt.USER_ACTION:
                                n.userActionCount += 1, e(n);
                                break;
                            case mt.LONG_TASK:
                                n.longTaskCount += 1, e(n);
                                break;
                            case mt.RESOURCE:
                                n.resourceCount += 1, e(n)
                        }
                    })),
                    i = t.subscribe(pt.RAW_RUM_EVENT_V2_COLLECTED, (function(t) {
                        switch (t.rawRumEvent.type) {
                            case vt.ERROR:
                                n.errorCount += 1, e(n);
                                break;
                            case vt.ACTION:
                                n.userActionCount += 1, e(n);
                                break;
                            case vt.LONG_TASK:
                                n.longTaskCount += 1, e(n);
                                break;
                            case vt.RESOURCE:
                                n.resourceCount += 1, e(n)
                        }
                    }));
                return {
                    stop: function() {
                        r.unsubscribe(), i.unsubscribe()
                    },
                    eventCounts: n
                }
            }! function(t) {
                t.USER_ACTION = "user_action", t.ERROR = "error", t.LONG_TASK = "long_task", t.VIEW = "view", t.RESOURCE = "resource"
            }(mt || (mt = {})),
            function(t) {
                t.ACTION = "action", t.ERROR = "error", t.LONG_TASK = "long_task", t.VIEW = "view", t.RESOURCE = "resource"
            }(vt || (vt = {}));
            var gt = function() {
                function t() {
                    this.observers = []
                }
                return t.prototype.subscribe = function(t) {
                    this.observers.push(t)
                }, t.prototype.notify = function(t) {
                    this.observers.forEach((function(e) {
                        return e(t)
                    }))
                }, t
            }();

            function bt(t, e) {
                var n = function(t) {
                        var e, n = new gt,
                            r = [],
                            i = 0;

                        function o() {
                            n.notify({
                                isBusy: i > 0
                            })
                        }
                        return r.push(t.subscribe(pt.DOM_MUTATED, (function() {
                            return o()
                        }))), r.push(t.subscribe(pt.PERFORMANCE_ENTRY_COLLECTED, (function(t) {
                            "resource" === t.entryType && o()
                        }))), r.push(t.subscribe(pt.REQUEST_STARTED, (function(t) {
                            void 0 === e && (e = t.requestIndex), i += 1, o()
                        }))), r.push(t.subscribe(pt.REQUEST_COMPLETED, (function(t) {
                            void 0 === e || t.requestIndex < e || (i -= 1, o())
                        }))), {
                            observable: n,
                            stop: function() {
                                r.forEach((function(t) {
                                    return t.unsubscribe()
                                }))
                            }
                        }
                    }(t),
                    r = n.observable,
                    i = n.stop,
                    o = function(t, e, n) {
                        var r, i = !1,
                            o = setTimeout(_((function() {
                                return s(!1, 0)
                            })), 100),
                            a = setTimeout(_((function() {
                                return s(!0, performance.now())
                            })), 1e4);

                        function u() {
                            i = !0, clearTimeout(o), clearTimeout(r), clearTimeout(a), e()
                        }

                        function s(t, e) {
                            i || (u(), n(t, e))
                        }
                        return t.subscribe((function(t) {
                            var e = t.isBusy;
                            clearTimeout(o), clearTimeout(r);
                            var n = performance.now();
                            e || (r = setTimeout(_((function() {
                                return s(!0, n)
                            })), 100))
                        })), {
                            stop: u
                        }
                    }(r, i, e).stop;
                return {
                    stop: function() {
                        o(), i()
                    }
                }
            }

            function yt(t) {
                return function(t) {
                    var e;
                    if (function() {
                            void 0 === Rt && (Rt = "closest" in HTMLElement.prototype);
                            return Rt
                        }()) e = t.closest("[data-dd-action-name]");
                    else
                        for (var n = t; n;) {
                            if (n.hasAttribute("data-dd-action-name")) {
                                e = n;
                                break
                            }
                            n = n.parentElement
                        }
                    if (!e) return;
                    return Nt(It(e.getAttribute("data-dd-action-name").trim()))
                }(t) || At(t, St) || At(t, wt) || ""
            }
            var Ct, Ot, Rt, _t, St = [function(t) {
                    if (function() {
                            void 0 === Ot && (Ot = "labels" in HTMLInputElement.prototype);
                            return Ot
                        }()) {
                        if ("labels" in t && t.labels && t.labels.length > 0) return Lt(t.labels[0])
                    } else if (t.id) {
                        var e = t.ownerDocument && t.ownerDocument.querySelector('label[for="' + t.id.replace('"', '\\"') + '"]');
                        return e && Lt(e)
                    }
                }, function(t) {
                    if ("INPUT" === t.nodeName) {
                        var e = t,
                            n = e.getAttribute("type");
                        if ("button" === n || "submit" === n || "reset" === n) return e.value
                    }
                }, function(t) {
                    if ("BUTTON" === t.nodeName || "LABEL" === t.nodeName || "button" === t.getAttribute("role")) return Lt(t)
                }, function(t) {
                    return t.getAttribute("aria-label")
                }, function(t) {
                    var e = t.getAttribute("aria-labelledby");
                    if (e) return e.split(/\s+/).map((function(e) {
                        return function(t, e) {
                            return t.ownerDocument ? t.ownerDocument.getElementById(e) : null
                        }(t, e)
                    })).filter((function(t) {
                        return Boolean(t)
                    })).map(Lt).join(" ")
                }, function(t) {
                    return t.getAttribute("alt")
                }, function(t) {
                    return t.getAttribute("name")
                }, function(t) {
                    return t.getAttribute("title")
                }, function(t) {
                    return t.getAttribute("placeholder")
                }, function(t) {
                    if ("options" in t && t.options.length > 0) return Lt(t.options[0])
                }],
                wt = [function(t) {
                    return Lt(t)
                }];

            function At(t, e) {
                for (var n = t, r = 0; r <= 10 && n && "BODY" !== n.nodeName && "HTML" !== n.nodeName && "HEAD" !== n.nodeName;) {
                    for (var i = 0, o = e; i < o.length; i++) {
                        var a = (0, o[i])(n);
                        if ("string" == typeof a) {
                            var u = a.trim();
                            if (u) return Nt(It(u))
                        }
                    }
                    if ("FORM" === n.nodeName) break;
                    n = n.parentElement, r += 1
                }
            }

            function It(t) {
                return t.replace(/\s+/g, " ")
            }

            function Nt(t) {
                return t.length > 100 ? (n = 100, ((r = (e = t).charCodeAt(n - 1)) >= 55296 && r <= 56319 ? e.slice(0, n + 1) : e.slice(0, n)) + " [...]") : t;
                var e, n, r
            }

            function Lt(t) {
                if (!t.isContentEditable) {
                    if ("innerText" in t) {
                        var e = t.innerText;
                        if (! function() {
                                if (void 0 === Ct) {
                                    var t = document.createElement("style");
                                    t.textContent = "*";
                                    var e = document.createElement("div");
                                    e.appendChild(t), document.body.appendChild(e), Ct = "" === e.innerText, document.body.removeChild(e)
                                }
                                return Ct
                            }())
                            for (var n = t.querySelectorAll("script, style"), r = 0; r < n.length; r += 1) {
                                var i = n[r].innerText;
                                i.trim().length > 0 && (e = e.replace(i, ""))
                            }
                        return e
                    }
                    return t.textContent
                }
            }

            function Dt(t) {
                var e = function(t) {
                    var e, n;
                    return {
                        create: function(r, i) {
                            if (!e) {
                                var o = new Mt(t, r, i);
                                e = o, n = bt(t, (function(t, n) {
                                    t ? o.complete(n) : o.discard(), e = void 0
                                }))
                            }
                        },
                        discardCurrent: function() {
                            e && (n.stop(), e.discard(), e = void 0)
                        }
                    }
                }(t);
                t.subscribe(pt.VIEW_CREATED, (function() {
                    e.discardCurrent()
                }));
                var n = X(window, L.CLICK, (function(t) {
                    if (t.target instanceof Element) {
                        var n = yt(t.target);
                        n && e.create(_t.CLICK, n)
                    }
                }), {
                    capture: !0
                }).stop;
                return {
                    stop: function() {
                        e.discardCurrent(), n()
                    }
                }
            }! function(t) {
                t.CLICK = "click", t.CUSTOM = "custom"
            }(_t || (_t = {}));
            var Ut, Mt = function() {
                function t(t, e, n) {
                    this.lifeCycle = t, this.type = e, this.name = n, this.id = k(), this.startTime = performance.now(), this.eventCountsSubscription = ht(t), this.lifeCycle.notify(pt.AUTO_ACTION_CREATED, {
                        id: this.id,
                        startTime: this.startTime
                    })
                }
                return t.prototype.complete = function(t) {
                    var e = this.eventCountsSubscription.eventCounts;
                    this.lifeCycle.notify(pt.AUTO_ACTION_COMPLETED, {
                        counts: {
                            errorCount: e.errorCount,
                            longTaskCount: e.longTaskCount,
                            resourceCount: e.resourceCount
                        },
                        duration: t - this.startTime,
                        id: this.id,
                        name: this.name,
                        startTime: this.startTime,
                        type: this.type
                    }), this.eventCountsSubscription.stop()
                }, t.prototype.discard = function() {
                    this.lifeCycle.notify(pt.AUTO_ACTION_DISCARDED), this.eventCountsSubscription.stop()
                }, t
            }();

            function xt(t) {
                var e, n = function() {
                    var t, e = window;
                    if (e.Zone) {
                        var n = e.Zone.__symbol__("MutationObserver");
                        t = e[n]
                    }
                    return t || (t = e.MutationObserver), t
                }();
                return n && (e = new n(_((function() {
                    t.notify(pt.DOM_MUTATED)
                })))).observe(document.documentElement, {
                    attributes: !0,
                    characterData: !0,
                    childList: !0,
                    subtree: !0
                }), {
                    stop: function() {
                        e && e.disconnect()
                    }
                }
            }

            function kt(t) {
                return Pt(t, Y(window.location)).href
            }

            function Vt(t) {
                return Y(Pt(t))
            }

            function Pt(t, e) {
                if (function() {
                        if (void 0 !== Ut) return Ut;
                        try {
                            var t = new URL("http://test/path");
                            return Ut = "http://test/path" === t.href
                        } catch (t) {
                            Ut = !1
                        }
                        return Ut
                    }()) return void 0 !== e ? new URL(t, e) : new URL(t);
                if (void 0 === e && !/:/.test(t)) throw new Error("Invalid URL: '" + t + "'");
                var n = document,
                    r = n.createElement("a");
                if (void 0 !== e) {
                    var i = (n = document.implementation.createHTMLDocument("")).createElement("base");
                    i.href = e, n.head.appendChild(i), n.body.appendChild(r)
                }
                return r.href = t, r
            }
            var Wt = [
                [D.DOCUMENT, function(t) {
                    return "initial_document" === t
                }],
                [D.XHR, function(t) {
                    return "xmlhttprequest" === t
                }],
                [D.FETCH, function(t) {
                    return "fetch" === t
                }],
                [D.BEACON, function(t) {
                    return "beacon" === t
                }],
                [D.CSS, function(t, e) {
                    return null !== e.match(/\.css$/i)
                }],
                [D.JS, function(t, e) {
                    return null !== e.match(/\.js$/i)
                }],
                [D.IMAGE, function(t, e) {
                    return H(["image", "img", "icon"], t) || null !== e.match(/\.(gif|jpg|jpeg|tiff|png|svg|ico)$/i)
                }],
                [D.FONT, function(t, e) {
                    return null !== e.match(/\.(woff|eot|woff2|ttf)$/i)
                }],
                [D.MEDIA, function(t, e) {
                    return H(["audio", "video"], t) || null !== e.match(/\.(mp3|mp4)$/i)
                }]
            ];

            function jt(t) {
                var e = t.name;
                if (! function(t) {
                        try {
                            return !!Pt(t)
                        } catch (t) {
                            return !1
                        }
                    }(e)) return S('Failed to construct URL for "' + t.name + '"'), D.OTHER;
                for (var n = function(t) {
                        var e = Pt(t).pathname;
                        return "/" === e[0] ? e : "/" + e
                    }(e), r = 0, i = Wt; r < i.length; r++) {
                    var o = i[r],
                        a = o[0];
                    if ((0, o[1])(t.initiatorType, n)) return a
                }
                return D.OTHER
            }

            function Bt() {
                for (var t = [], e = 0; e < arguments.length; e++) t[e] = arguments[e];
                for (var n = 1; n < t.length; n += 1)
                    if (t[n - 1] > t[n]) return !1;
                return !0
            }

            function Ht(t) {
                var e = t.duration,
                    n = t.startTime,
                    r = t.responseEnd;
                return P(0 === e && n < r ? r - n : e)
            }

            function Ft(t) {
                var e = Gt(t);
                if (e) {
                    var n = e.startTime,
                        r = e.fetchStart,
                        i = e.redirectStart,
                        o = e.redirectEnd,
                        a = e.domainLookupStart,
                        u = e.domainLookupEnd,
                        s = e.connectStart,
                        c = e.secureConnectionStart,
                        f = e.connectEnd,
                        d = e.requestStart,
                        l = e.responseStart,
                        p = {
                            download: Kt(n, l, e.responseEnd),
                            firstByte: Kt(n, d, l)
                        };
                    return f !== r && (p.connect = Kt(n, s, f), Bt(s, c, f) && (p.ssl = Kt(n, c, f))), u !== r && (p.dns = Kt(n, a, u)), qt(t) && (p.redirect = Kt(n, i, o)), p
                }
            }

            function Gt(t) {
                if (Bt(t.startTime, t.fetchStart, t.domainLookupStart, t.domainLookupEnd, t.connectStart, t.connectEnd, t.requestStart, t.responseStart, t.responseEnd)) {
                    if (!qt(t)) return t;
                    var e = t.redirectStart,
                        n = t.redirectEnd;
                    if (e < t.startTime && (e = t.startTime), n < t.startTime && (n = t.fetchStart), Bt(t.startTime, e, n, t.fetchStart)) return Object(r.a)(Object(r.a)({}, t), {
                        redirectEnd: n,
                        redirectStart: e
                    })
                }
            }

            function qt(t) {
                return t.fetchStart !== t.startTime
            }

            function Kt(t, e, n) {
                return {
                    duration: P(n - e),
                    start: P(e - t)
                }
            }

            function zt(t) {
                if (t.startTime < t.responseStart) return t.decodedBodySize
            }

            function Yt(t, e) {
                return e && !t.isIntakeUrl(e)
            }
            var $t, Xt;

            function Jt(t) {
                var e = function(t) {
                    var e = t.querySelector("meta[name=dd-trace-id]"),
                        n = t.querySelector("meta[name=dd-trace-time]");
                    return Qt(e && e.content, n && n.content)
                }(t) || function(t) {
                    var e = function(t) {
                        for (var e = 0; e < t.childNodes.length; e += 1) {
                            if (n = Zt(t.childNodes[e])) return n
                        }
                        if (t.body)
                            for (e = t.body.childNodes.length - 1; e >= 0; e -= 1) {
                                var n, r = t.body.childNodes[e];
                                if (n = Zt(r)) return n;
                                if (!te(r)) break
                            }
                    }(t);
                    if (!e) return;
                    return Qt($(e, "trace-id"), $(e, "trace-time"))
                }(t);
                if (e && !(e.traceTime <= Date.now() - 12e4)) return e.traceId
            }

            function Qt(t, e) {
                var n = e && Number(e);
                if (t && n) return {
                    traceId: t,
                    traceTime: n
                }
            }

            function Zt(t) {
                if (t && function(t) {
                        return "#comment" === t.nodeName
                    }(t)) {
                    var e = t.data.match(/^\s*DATADOG;(.*?)\s*$/);
                    if (e) return e[1]
                }
            }

            function te(t) {
                return "#text" === t.nodeName
            }

            function ee() {
                return void 0 !== window.performance && "getEntries" in performance
            }

            function ne(t) {
                return window.PerformanceObserver && void 0 !== PerformanceObserver.supportedEntryTypes && PerformanceObserver.supportedEntryTypes.includes(t)
            }

            function re(t, e) {
                var n;
                if (n = function(n) {
                        ue(t, e, n)
                    }, ie("interactive", (function() {
                        var t, e = {
                            entryType: "resource",
                            initiatorType: "initial_document",
                            traceId: Jt(document)
                        };
                        if (ne("navigation") && performance.getEntriesByType("navigation").length > 0) {
                            var i = performance.getEntriesByType("navigation")[0];
                            t = Object(r.a)(Object(r.a)({}, i.toJSON()), e)
                        } else {
                            var o = oe();
                            t = Object(r.a)(Object(r.a)(Object(r.a)({}, o), {
                                decodedBodySize: 0,
                                duration: o.responseEnd,
                                name: window.location.href,
                                startTime: 0
                            }), e)
                        }
                        n(t)
                    })), ee() && ae(t, e, performance.getEntries()), window.PerformanceObserver) {
                    new PerformanceObserver(_((function(n) {
                        return ae(t, e, n.getEntries())
                    }))).observe({
                        entryTypes: ["resource", "navigation", "longtask", "paint", "largest-contentful-paint", "first-input", "layout-shift"]
                    }), ee() && "addEventListener" in performance && performance.addEventListener("resourcetimingbufferfull", (function() {
                        performance.clearResourceTimings()
                    }))
                }
                ne("navigation") || function(t) {
                    function e() {
                        t(Object(r.a)(Object(r.a)({}, oe()), {
                            entryType: "navigation"
                        }))
                    }
                    ie("complete", (function() {
                        setTimeout(_(e))
                    }))
                }((function(n) {
                    ue(t, e, n)
                })), ne("first-input") || function(t) {
                    var e = Date.now(),
                        n = !1,
                        r = J(window, [L.CLICK, L.MOUSE_DOWN, L.KEY_DOWN, L.TOUCH_START, L.POINTER_DOWN], (function(t) {
                            if (t.cancelable) {
                                var e = {
                                    entryType: "first-input",
                                    processingStart: performance.now(),
                                    startTime: t.timeStamp
                                };
                                t.type === L.POINTER_DOWN ? function(t) {
                                    J(window, [L.POINTER_UP, L.POINTER_CANCEL], (function(e) {
                                        e.type === L.POINTER_UP && i(t)
                                    }), {
                                        once: !0
                                    })
                                }(e) : i(e)
                            }
                        }), {
                            passive: !0,
                            capture: !0
                        }).stop;

                    function i(i) {
                        if (!n) {
                            n = !0, r();
                            var o = i.processingStart - i.startTime;
                            o >= 0 && o < Date.now() - e && t(i)
                        }
                    }
                }((function(n) {
                    ue(t, e, n)
                }))
            }

            function ie(t, e) {
                if (document.readyState === t || "complete" === document.readyState) e();
                else {
                    var n = "complete" === t ? L.LOAD : L.DOM_CONTENT_LOADED;
                    X(window, n, e, {
                        once: !0
                    })
                }
            }

            function oe() {
                var t = {},
                    e = performance.timing;
                for (var n in e) G(e[n]) && (t[n] = 0 === e[n] ? 0 : e[n] - K());
                return t
            }

            function ae(t, e, n) {
                n.forEach((function(n) {
                    "resource" !== n.entryType && "navigation" !== n.entryType && "paint" !== n.entryType && "longtask" !== n.entryType && "largest-contentful-paint" !== n.entryType && "first-input" !== n.entryType && "layout-shift" !== n.entryType || ue(t, e, n)
                }))
            }

            function ue(t, e, n) {
                (function(t) {
                    return "navigation" === t.entryType && t.loadEventEnd <= 0
                })(n) || function(t, e) {
                    return "resource" === e.entryType && !Yt(t, e.name)
                }(e, n) || t.notify(pt.PERFORMANCE_ENTRY_COLLECTED, n)
            }

            function se(t, e, n, r, o, a) {
                n.subscribe(pt.RAW_RUM_EVENT_COLLECTED, (function(u) {
                    var c, f = u.startTime,
                        d = u.rawRumEvent,
                        l = u.savedGlobalContext,
                        p = u.customerContext,
                        E = o.findView(f);
                    if (r.isTracked() && E && E.sessionId) {
                        var m = o.findAction(f),
                            v = {
                                applicationId: t,
                                date: (new Date).getTime(),
                                service: e.service,
                                session: {
                                    type: void 0 === window._DATADOG_SYNTHETICS_BROWSER ? $t.USER : $t.SYNTHETICS
                                }
                            },
                            T = (c = d, -1 !== [mt.ERROR, mt.RESOURCE, mt.LONG_TASK].indexOf(c.evt.category) ? s(v, E, m, d) : s(v, E, d)),
                            h = s(l || a(), p, i(T));
                        n.notify(pt.RUM_EVENT_COLLECTED, {
                            rumEvent: T,
                            serverRumEvent: h
                        })
                    }
                }))
            }

            function ce(t, e, n, r, o, a) {
                n.subscribe(pt.RAW_RUM_EVENT_V2_COLLECTED, (function(u) {
                    var c, f = u.startTime,
                        d = u.rawRumEvent,
                        l = u.savedGlobalContext,
                        p = u.customerContext,
                        E = o.findViewV2(f);
                    if (r.isTracked() && E && E.session.id) {
                        var m = o.findActionV2(f),
                            v = {
                                _dd: {
                                    formatVersion: 2
                                },
                                application: {
                                    id: t
                                },
                                date: (new Date).getTime(),
                                service: e.service,
                                session: {
                                    type: void 0 === window._DATADOG_SYNTHETICS_BROWSER ? Xt.USER : Xt.SYNTHETICS
                                }
                            },
                            T = (c = d, -1 !== [vt.ERROR, vt.RESOURCE, vt.LONG_TASK].indexOf(c.type) ? s(v, E, m, d) : s(v, E, d)),
                            h = i(T);
                        h.context = s(l || a(), p), n.notify(pt.RUM_EVENT_V2_COLLECTED, {
                            rumEvent: T,
                            serverRumEvent: h
                        })
                    }
                }))
            }! function(t) {
                t.SYNTHETICS = "synthetics", t.USER = "user"
            }($t || ($t = {})),
            function(t) {
                t.SYNTHETICS = "synthetics", t.USER = "user"
            }(Xt || (Xt = {}));

            function fe(t, e, n) {
                var r = function(t, e) {
                    var n, r, i = !1,
                        o = function() {
                            i = !0, window.clearTimeout(n), n = window.setTimeout((function() {
                                i = !1
                            }), 1e3)
                        };
                    return {
                        get: function() {
                            return i || (r = tt(t), o()), r
                        },
                        set: function(n, i) {
                            Z(t, n, i, e), r = n, o()
                        }
                    }
                }("_dd_s", t);
                ! function(t) {
                    var e = t.get(),
                        n = tt("_dd"),
                        r = tt("_dd_r"),
                        i = tt("_dd_l");
                    if (!e) {
                        var o = {};
                        n && (o.id = n), i && /^[01]$/.test(i) && (o.logs = i), r && /^[012]$/.test(r) && (o.rum = r), pe(o, t)
                    }
                }(r);
                var i = new gt,
                    o = le(r).id,
                    a = x((function() {
                        var t = le(r),
                            a = n(t[e]),
                            u = a.trackingType,
                            s = a.isTracked;
                        t[e] = u, s && !t.id && (t.id = k(), t.created = String(Date.now())), pe(t, r), s && o !== t.id && (o = t.id, i.notify())
                    }), 1e3).throttled;
                return a(),
                    function(t) {
                        var e = J(window, [L.CLICK, L.TOUCH_START, L.KEY_DOWN, L.SCROLL], t, {
                            capture: !0,
                            passive: !0
                        }).stop;
                        me.push(e)
                    }(a),
                    function(t) {
                        var e = _((function() {
                                "visible" === document.visibilityState && t()
                            })),
                            n = X(document, L.VISIBILITY_CHANGE, e).stop;
                        me.push(n);
                        var r = window.setInterval(e, 6e4);
                        me.push((function() {
                            clearInterval(r)
                        }))
                    }((function() {
                        pe(le(r), r)
                    })), {
                        getId: function() {
                            return le(r).id
                        },
                        getTrackingType: function() {
                            return le(r)[e]
                        },
                        renewObservable: i
                    }
            }
            var de = /^([a-z]+)=([a-z0-9-]+)$/;

            function le(t) {
                var e = function(t) {
                    var e = t.get(),
                        n = {};
                    (function(t) {
                        return void 0 !== t && (-1 !== t.indexOf("&") || de.test(t))
                    })(e) && e.split("&").forEach((function(t) {
                        var e = de.exec(t);
                        if (null !== e) {
                            var r = e[1],
                                i = e[2];
                            n[r] = i
                        }
                    }));
                    return n
                }(t);
                return function(t) {
                    return (void 0 === t.created || Date.now() - Number(t.created) < 144e5) && (void 0 === t.expire || Date.now() < Number(t.expire))
                }(e) ? e : (Ee(t), {})
            }

            function pe(t, e) {
                if (n = t, 0 !== Object.keys(n).length) {
                    var n;
                    t.expire = String(Date.now() + 9e5);
                    var r = z(t).map((function(t) {
                        return t[0] + "=" + t[1]
                    })).join("&");
                    e.set(r, 9e5)
                } else Ee(e)
            }

            function Ee(t) {
                t.set("", 0)
            }
            var me = [];
            var ve;
            var Te, he, ge, be, ye = [],
                Ce = [];

            function Oe() {
                return ve || (Te = XMLHttpRequest.prototype.open, he = XMLHttpRequest.prototype.send, XMLHttpRequest.prototype.open = _((function(t, e) {
                    return this._datadog_xhr = {
                        method: t,
                        startTime: -1,
                        url: kt(e)
                    }, Te.apply(this, arguments)
                })), XMLHttpRequest.prototype.send = _((function(t) {
                    var e = this;
                    if (this._datadog_xhr) {
                        this._datadog_xhr.startTime = performance.now();
                        var n = this.onreadystatechange;
                        this.onreadystatechange = function() {
                            this.readyState === XMLHttpRequest.DONE && _(i)(), n && n.apply(this, arguments)
                        };
                        var r = !1,
                            i = function() {
                                r || (r = !0, e._datadog_xhr.duration = performance.now() - e._datadog_xhr.startTime, e._datadog_xhr.response = e.response, e._datadog_xhr.status = e.status, Ce.forEach((function(t) {
                                    return t(e._datadog_xhr)
                                })))
                            };
                        this.addEventListener("loadend", _(i)), ye.forEach((function(t) {
                            return t(e._datadog_xhr, e)
                        }))
                    }
                    return he.apply(this, arguments)
                })), ve = {
                    beforeSend: function(t) {
                        ye.push(t)
                    },
                    onRequestComplete: function(t) {
                        Ce.push(t)
                    }
                }), ve
            }
            var Re = [],
                _e = [];

            function Se() {
                return ge || (! function() {
                    if (!window.fetch) return;
                    be = window.fetch, window.fetch = _((function(t, e) {
                        var n = this,
                            i = e && e.method || "object" == typeof t && t.method || "GET",
                            o = kt("object" == typeof t && t.url || t),
                            a = {
                                init: e,
                                method: i,
                                startTime: performance.now(),
                                url: o
                            },
                            u = function(t) {
                                return Object(r.b)(n, void 0, void 0, (function() {
                                    var e, n;
                                    return Object(r.d)(this, (function(r) {
                                        switch (r.label) {
                                            case 0:
                                                return a.duration = performance.now() - a.startTime, "stack" in t || t instanceof Error ? (a.status = 0, a.response = p(y(t)), _e.forEach((function(t) {
                                                    return t(a)
                                                })), [3, 6]) : [3, 1];
                                            case 1:
                                                if (!("status" in t)) return [3, 6];
                                                e = void 0, r.label = 2;
                                            case 2:
                                                return r.trys.push([2, 4, , 5]), [4, t.clone().text()];
                                            case 3:
                                                return e = r.sent(), [3, 5];
                                            case 4:
                                                return n = r.sent(), e = "Unable to retrieve response: " + n, [3, 5];
                                            case 5:
                                                a.response = e, a.responseType = t.type, a.status = t.status, _e.forEach((function(t) {
                                                    return t(a)
                                                })), r.label = 6;
                                            case 6:
                                                return [2]
                                        }
                                    }))
                                }))
                            };
                        Re.forEach((function(t) {
                            return t(a)
                        }));
                        var s = be.call(this, t, a.init);
                        return s.then(_(u), _(u)), s
                    }))
                }(), ge = {
                    beforeSend: function(t) {
                        Re.push(t)
                    },
                    onRequestComplete: function(t) {
                        _e.push(t)
                    }
                }), ge
            }

            function we(t) {
                0 === t.status && (t.traceId = void 0, t.spanId = void 0)
            }

            function Ae(t, e, n) {
                var r;
                void 0 !== Ie() && function(t, e) {
                    for (var n = Vt(e), r = 0, i = t.allowedTracingOrigins; r < i.length; r++) {
                        var o = i[r];
                        if (n === o || o instanceof RegExp && o.test(n)) return !0
                    }
                    return !1
                }(t, e.url) && (e.traceId = new xe, e.spanId = new xe, n((r = e.traceId, {
                    "x-datadog-origin": "rum",
                    "x-datadog-parent-id": e.spanId.toDecimalString(),
                    "x-datadog-sampled": "1",
                    "x-datadog-sampling-priority": "1",
                    "x-datadog-trace-id": r.toDecimalString()
                })))
            }

            function Ie() {
                return window.crypto || window.msCrypto
            }
            var Ne, Le, De, Ue, Me, xe = function() {
                    function t() {
                        this.buffer = new Uint8Array(8), Ie().getRandomValues(this.buffer), this.buffer[0] = 127 & this.buffer[0]
                    }
                    return t.prototype.toString = function(t) {
                        for (var e = this.readInt32(0), n = this.readInt32(4), r = "";;) {
                            var i = e % t * 4294967296 + n;
                            if (e = Math.floor(e / t), n = Math.floor(i / t), r = (i % t).toString(t) + r, !e && !n) break
                        }
                        return r
                    }, t.prototype.toDecimalString = function() {
                        return this.toString(10)
                    }, t.prototype.readInt32 = function(t) {
                        return 16777216 * this.buffer[t] + (this.buffer[t + 1] << 16) + (this.buffer[t + 2] << 8) + this.buffer[t + 3]
                    }, t
                }(),
                ke = 1;

            function Ve(t, e) {
                var n = function(t) {
                    return {
                        clearTracingIfCancelled: we,
                        traceFetch: function(e) {
                            return Ae(t, e, (function(t) {
                                e.init = Object(r.a)({}, e.init);
                                var n = [];
                                e.init.headers instanceof Headers ? e.init.headers.forEach((function(t, e) {
                                    n.push([e, t])
                                })) : Array.isArray(e.init.headers) ? e.init.headers.forEach((function(t) {
                                    n.push(t)
                                })) : e.init.headers && Object.keys(e.init.headers).forEach((function(t) {
                                    n.push([t, e.init.headers[t]])
                                })), e.init.headers = n.concat(z(t))
                            }))
                        },
                        traceXhr: function(e, n) {
                            return Ae(t, e, (function(t) {
                                Object.keys(t).forEach((function(e) {
                                    n.setRequestHeader(e, t[e])
                                }))
                            }))
                        }
                    }
                }(e);
                ! function(t, e, n) {
                    var r = Oe();
                    r.beforeSend((function(r, i) {
                        Yt(e, r.url) && (n.traceXhr(r, i), r.requestIndex = Pe(), t.notify(pt.REQUEST_STARTED, {
                            requestIndex: r.requestIndex
                        }))
                    })), r.onRequestComplete((function(r) {
                        Yt(e, r.url) && (n.clearTracingIfCancelled(r), t.notify(pt.REQUEST_COMPLETED, {
                            duration: r.duration,
                            method: r.method,
                            requestIndex: r.requestIndex,
                            response: r.response,
                            spanId: r.spanId,
                            startTime: r.startTime,
                            status: r.status,
                            traceId: r.traceId,
                            type: U.XHR,
                            url: r.url
                        }))
                    }))
                }(t, e, n),
                function(t, e, n) {
                    var r = Se();
                    r.beforeSend((function(r) {
                        Yt(e, r.url) && (n.traceFetch(r), r.requestIndex = Pe(), t.notify(pt.REQUEST_STARTED, {
                            requestIndex: r.requestIndex
                        }))
                    })), r.onRequestComplete((function(r) {
                        Yt(e, r.url) && (n.clearTracingIfCancelled(r), t.notify(pt.REQUEST_COMPLETED, {
                            duration: r.duration,
                            method: r.method,
                            requestIndex: r.requestIndex,
                            response: r.response,
                            responseType: r.responseType,
                            spanId: r.spanId,
                            startTime: r.startTime,
                            status: r.status,
                            traceId: r.traceId,
                            type: U.FETCH,
                            url: r.url
                        }))
                    }))
                }(t, e, n)
            }

            function Pe() {
                var t = ke;
                return ke += 1, t
            }

            function We(t, e) {
                return t.subscribe(pt.AUTO_ACTION_COMPLETED, (function(n) {
                    e.isEnabled("v2_format") ? t.notify(pt.RAW_RUM_EVENT_V2_COLLECTED, Be(n)) : t.notify(pt.RAW_RUM_EVENT_COLLECTED, je(n))
                })), e.trackInteractions && Dt(t), {
                    addAction: function(n, i) {
                        e.isEnabled("v2_format") ? t.notify(pt.RAW_RUM_EVENT_V2_COLLECTED, Object(r.a)({
                            savedGlobalContext: i
                        }, Be(n))) : t.notify(pt.RAW_RUM_EVENT_COLLECTED, Object(r.a)({
                            savedGlobalContext: i
                        }, je(n)))
                    }
                }
            }

            function je(t) {
                var e = He(t) ? {
                    duration: P(t.duration),
                    userAction: {
                        id: t.id,
                        measures: t.counts
                    }
                } : void 0;
                return {
                    customerContext: He(t) ? void 0 : t.context,
                    rawRumEvent: s({
                        date: q(t.startTime),
                        evt: {
                            category: mt.USER_ACTION,
                            name: t.name
                        },
                        userAction: {
                            type: t.type
                        }
                    }, e),
                    startTime: t.startTime
                }
            }

            function Be(t) {
                var e = He(t) ? {
                    action: {
                        error: {
                            count: t.counts.errorCount
                        },
                        id: t.id,
                        loadingTime: P(t.duration),
                        longTask: {
                            count: t.counts.longTaskCount
                        },
                        resource: {
                            count: t.counts.resourceCount
                        }
                    }
                } : void 0;
                return {
                    customerContext: He(t) ? void 0 : t.context,
                    rawRumEvent: s({
                        action: {
                            target: {
                                name: t.name
                            },
                            type: t.type
                        },
                        date: q(t.startTime),
                        type: vt.ACTION
                    }, e),
                    startTime: t.startTime
                }
            }

            function He(t) {
                return t.type !== _t.CUSTOM
            }

            function Fe(t) {
                if (!Ne) {
                    var e = new gt;
                    ! function(t, e) {
                        function n(n, r) {
                            t.isIntakeUrl(r.url) || ! function(t) {
                                return 0 === t.status && "opaque" !== t.responseType
                            }(r) && ! function(t) {
                                return t.status >= 500
                            }(r) || e.notify({
                                message: Ke(n) + " error " + r.method + " " + r.url,
                                resource: {
                                    method: r.method,
                                    statusCode: r.status,
                                    url: r.url
                                },
                                source: o.NETWORK,
                                stack: qe(r.response, t) || "Failed to load",
                                startTime: r.startTime
                            })
                        }
                        Oe().onRequestComplete((function(t) {
                            return n(U.XHR, t)
                        })), Se().onRequestComplete((function(t) {
                            return n(U.FETCH, t)
                        }))
                    }(t, e),
                    function(t) {
                        Le = console.error, console.error = _((function(e) {
                            for (var n = [], i = 1; i < arguments.length; i++) n[i - 1] = arguments[i];
                            Le.apply(console, Object(r.f)([e], n)), t.notify({
                                message: Object(r.f)(["console error:", e], n).map(Ge).join(" "),
                                source: o.CONSOLE,
                                startTime: performance.now()
                            })
                        }))
                    }(e),
                    function(t) {
                        De = function(e, n, r) {
                            var i = l(e, r, "Uncaught"),
                                a = i.stack,
                                u = i.message,
                                s = i.type;
                            t.notify({
                                message: u,
                                stack: a,
                                type: s,
                                source: o.SOURCE,
                                startTime: performance.now()
                            })
                        }, b.subscribe(De)
                    }(e), Ne = function(t, e) {
                        var n = 0,
                            r = new gt;
                        return e.subscribe((function(e) {
                            n < t.maxErrorsByMinute ? (n += 1, r.notify(e)) : n === t.maxErrorsByMinute && (n += 1, r.notify({
                                message: "Reached max number of errors by minute: " + t.maxErrorsByMinute,
                                source: o.AGENT,
                                startTime: performance.now()
                            }))
                        })), setInterval((function() {
                            return n = 0
                        }), 6e4), r
                    }(t, e)
                }
                return Ne
            }

            function Ge(t) {
                return "string" == typeof t ? t : t instanceof Error ? p(y(t)) : j(t, 0, 2)
            }

            function qe(t, e) {
                return t && t.length > e.requestErrorResponseLengthLimit ? t.substring(0, e.requestErrorResponseLengthLimit) + "..." : t
            }

            function Ke(t) {
                return U.XHR === t ? "XHR" : "Fetch"
            }

            function ze(t, e) {
                return function(t, e, n) {
                    return n.subscribe((function(n) {
                        e.isEnabled("v2_format") ? t.notify(pt.RAW_RUM_EVENT_V2_COLLECTED, $e(n)) : t.notify(pt.RAW_RUM_EVENT_COLLECTED, Ye(n))
                    })), {
                        addError: function(n, i) {
                            var o = n.error,
                                a = n.startTime,
                                u = n.context,
                                s = function(t, e, n) {
                                    var i = t instanceof Error ? y(t) : void 0;
                                    return Object(r.a)({
                                        startTime: e,
                                        source: n
                                    }, l(i, t, "Provided"))
                                }(o, a, n.source);
                            e.isEnabled("v2_format") ? t.notify(pt.RAW_RUM_EVENT_V2_COLLECTED, Object(r.a)({
                                customerContext: u,
                                savedGlobalContext: i
                            }, $e(s))) : t.notify(pt.RAW_RUM_EVENT_COLLECTED, Object(r.a)({
                                customerContext: u,
                                savedGlobalContext: i
                            }, Ye(s)))
                        }
                    }
                }(t, e, Fe(e))
            }

            function Ye(t) {
                return {
                    rawRumEvent: s({
                        date: q(t.startTime),
                        error: {
                            kind: t.type,
                            origin: t.source,
                            stack: t.stack
                        },
                        evt: {
                            category: mt.ERROR
                        },
                        message: t.message
                    }, t.resource ? {
                        http: {
                            method: t.resource.method,
                            status_code: t.resource.statusCode,
                            url: t.resource.url
                        }
                    } : void 0),
                    startTime: t.startTime
                }
            }

            function $e(t) {
                return {
                    rawRumEvent: {
                        date: q(t.startTime),
                        error: {
                            message: t.message,
                            resource: t.resource,
                            source: t.source,
                            stack: t.stack,
                            type: t.type
                        },
                        type: vt.ERROR
                    },
                    startTime: t.startTime
                }
            }

            function Xe(t) {
                if (performance && "getEntriesByName" in performance) {
                    var e = performance.getEntriesByName(t.url, "resource");
                    if (e.length && "toJSON" in e[0]) {
                        var n, r = e.map((function(t) {
                            return t.toJSON()
                        })).filter(Gt).filter((function(e) {
                            return n = e, r = t.startTime, i = Je(t), n.startTime >= r && Je(n) <= i;
                            var n, r, i
                        }));
                        return 1 === r.length ? r[0] : 2 === r.length && Je((n = r)[0]) <= n[1].startTime ? r[1] : void 0
                    }
                }
            }

            function Je(t) {
                return t.startTime + t.duration
            }

            function Qe(t, e, n) {
                t.subscribe(pt.REQUEST_COMPLETED, (function(r) {
                    n.isTrackedWithResource() && (e.isEnabled("v2_format") ? t.notify(pt.RAW_RUM_EVENT_V2_COLLECTED, function(t) {
                        var e = t.type === U.XHR ? D.XHR : D.FETCH,
                            n = Xe(t),
                            r = n ? n.startTime : t.startTime,
                            i = n ? tn(n) : void 0,
                            o = en(t),
                            a = s({
                                date: q(r),
                                resource: {
                                    type: e,
                                    duration: P(t.duration),
                                    method: t.method,
                                    statusCode: t.status,
                                    url: t.url
                                },
                                type: vt.RESOURCE
                            }, o, i);
                        return {
                            startTime: r,
                            rawRumEvent: a
                        }
                    }(r)) : t.notify(pt.RAW_RUM_EVENT_COLLECTED, function(t) {
                        var e = t.type === U.XHR ? D.XHR : D.FETCH,
                            n = Xe(t),
                            r = n ? n.startTime : t.startTime,
                            i = n ? Ze(n) : void 0,
                            o = en(t),
                            a = s({
                                date: q(r),
                                duration: P(t.duration),
                                evt: {
                                    category: mt.RESOURCE
                                },
                                http: {
                                    method: t.method,
                                    statusCode: t.status,
                                    url: t.url
                                },
                                resource: {
                                    kind: e
                                }
                            }, o, i);
                        return {
                            startTime: r,
                            rawRumEvent: a
                        }
                    }(r)))
                })), t.subscribe(pt.PERFORMANCE_ENTRY_COLLECTED, (function(r) {
                    var i;
                    n.isTrackedWithResource() && "resource" === r.entryType && ("xmlhttprequest" !== (i = r).initiatorType && "fetch" !== i.initiatorType) && (e.isEnabled("v2_format") ? t.notify(pt.RAW_RUM_EVENT_V2_COLLECTED, function(t) {
                        var e = jt(t),
                            n = tn(t),
                            r = nn(t),
                            i = s({
                                date: q(t.startTime),
                                resource: {
                                    type: e,
                                    url: t.name
                                },
                                type: vt.RESOURCE
                            }, r, n);
                        return {
                            startTime: t.startTime,
                            rawRumEvent: i
                        }
                    }(r)) : t.notify(pt.RAW_RUM_EVENT_COLLECTED, function(t) {
                        var e = jt(t),
                            n = Ze(t),
                            r = nn(t),
                            i = s({
                                date: q(t.startTime),
                                evt: {
                                    category: mt.RESOURCE
                                },
                                http: {
                                    url: t.name
                                },
                                resource: {
                                    kind: e
                                }
                            }, r, n);
                        return {
                            startTime: t.startTime,
                            rawRumEvent: i
                        }
                    }(r)))
                }))
            }

            function Ze(t) {
                return {
                    duration: Ht(t),
                    http: {
                        performance: Ft(t)
                    },
                    network: {
                        bytesWritten: zt(t)
                    }
                }
            }

            function tn(t) {
                return {
                    resource: Object(r.a)({
                        duration: Ht(t),
                        size: zt(t)
                    }, Ft(t))
                }
            }

            function en(t) {
                if (t.traceId && t.spanId) return {
                    _dd: {
                        spanId: t.spanId.toDecimalString(),
                        traceId: t.traceId.toDecimalString()
                    },
                    resource: {
                        id: k()
                    }
                }
            }

            function nn(t) {
                return t.traceId ? {
                    _dd: {
                        traceId: t.traceId
                    }
                } : void 0
            }

            function rn(t) {
                return void 0 === t && (t = window), Ue || ("hidden" === document.visibilityState ? Ue = {
                    timeStamp: 0
                } : (Ue = {
                    timeStamp: 1 / 0
                }, X(t, L.PAGE_HIDE, (function(t) {
                    var e = t.timeStamp;
                    Ue.timeStamp = e
                }), {
                    capture: !0,
                    once: !0
                }).stop)), Ue
            }

            function on(t, e) {
                var n;

                function i(t) {
                    n = Object(r.a)(Object(r.a)({}, n), t), e(n)
                }
                var o = function(t, e) {
                        return {
                            stop: t.subscribe(pt.PERFORMANCE_ENTRY_COLLECTED, (function(t) {
                                "navigation" === t.entryType && e({
                                    domComplete: t.domComplete,
                                    domContentLoaded: t.domContentLoadedEventEnd,
                                    domInteractive: t.domInteractive,
                                    loadEventEnd: t.loadEventEnd
                                })
                            })).unsubscribe
                        }
                    }(t, i).stop,
                    a = function(t, e) {
                        var n = rn();
                        return {
                            stop: t.subscribe(pt.PERFORMANCE_ENTRY_COLLECTED, (function(t) {
                                "paint" === t.entryType && "first-contentful-paint" === t.name && t.startTime < n.timeStamp && e(t.startTime)
                            })).unsubscribe
                        }
                    }(t, (function(t) {
                        return i({
                            firstContentfulPaint: t
                        })
                    })).stop,
                    u = function(t, e, n) {
                        var r = rn(),
                            i = 1 / 0,
                            o = J(e, [L.POINTER_DOWN, L.KEY_DOWN], (function(t) {
                                i = t.timeStamp
                            }), {
                                capture: !0,
                                once: !0
                            }).stop,
                            a = t.subscribe(pt.PERFORMANCE_ENTRY_COLLECTED, (function(t) {
                                "largest-contentful-paint" === t.entryType && t.startTime < i && t.startTime < r.timeStamp && n(t.startTime)
                            })).unsubscribe;
                        return {
                            stop: function() {
                                o(), a()
                            }
                        }
                    }(t, window, (function(t) {
                        i({
                            largestContentfulPaint: t
                        })
                    })).stop,
                    s = function(t, e) {
                        var n = rn();
                        return {
                            stop: t.subscribe(pt.PERFORMANCE_ENTRY_COLLECTED, (function(t) {
                                "first-input" === t.entryType && t.startTime < n.timeStamp && e(t.processingStart - t.startTime)
                            })).unsubscribe
                        }
                    }(t, (function(t) {
                        i({
                            firstInputDelay: t
                        })
                    })).stop;
                return {
                    stop: function() {
                        o(), a(), u(), s()
                    }
                }
            }! function(t) {
                t.INITIAL_LOAD = "initial_load", t.ROUTE_CHANGE = "route_change"
            }(Me || (Me = {}));

            function an(t, e) {
                var n, r = un(e, t, Me.INITIAL_LOAD, document.referrer, 0),
                    i = r,
                    o = on(e, (function(t) {
                        r.updateTimings(t), r.scheduleUpdate()
                    })).stop;

                function a() {
                    i.isDifferentView(t) ? (i.triggerUpdate(), i.end(), i = un(e, t, Me.ROUTE_CHANGE, i.url)) : (i.updateLocation(t), i.triggerUpdate())
                }! function(t) {
                    var e = history.pushState;
                    history.pushState = _((function() {
                        e.apply(this, arguments), t()
                    }));
                    var n = history.replaceState;
                    history.replaceState = _((function() {
                        n.apply(this, arguments), t()
                    })), X(window, L.POP_STATE, t)
                }(a), n = a, X(window, L.HASH_CHANGE, n), e.subscribe(pt.SESSION_RENEWED, (function() {
                    i.end(), i = un(e, t, Me.ROUTE_CHANGE, i.url)
                })), e.subscribe(pt.BEFORE_UNLOAD, (function() {
                    i.triggerUpdate(), i.end()
                }));
                var u = window.setInterval(_((function() {
                    i.triggerUpdate()
                })), 3e5);
                return {
                    stop: function() {
                        o(), i.end(), clearInterval(u)
                    }
                }
            }

            function un(t, e, n, i, o) {
                void 0 === o && (o = performance.now());
                var a, u, s, c = k(),
                    f = {
                        errorCount: 0,
                        longTaskCount: 0,
                        resourceCount: 0,
                        userActionCount: 0
                    },
                    d = {},
                    l = 0,
                    p = Object(r.a)({}, e);
                t.notify(pt.VIEW_CREATED, {
                    id: c,
                    startTime: o,
                    location: p,
                    referrer: i
                });
                var E, m = x(_(O), 3e3, {
                        leading: !1
                    }),
                    v = m.throttled,
                    T = m.cancel,
                    h = ht(t, (function(t) {
                        f = t, v()
                    })).stop,
                    g = function(t, e) {
                        var n = t === Me.INITIAL_LOAD,
                            r = !0,
                            i = [];

                        function o() {
                            !r && !n && i.length > 0 && e(Math.max.apply(Math, i))
                        }
                        return {
                            setLoadEventEnd: function(t) {
                                n && (n = !1, i.push(t), o())
                            },
                            setActivityLoadingTime: function(t) {
                                r && (r = !1, void 0 !== t && i.push(t), o())
                            }
                        }
                    }(n, (function(t) {
                        u = t, v()
                    })),
                    b = g.setActivityLoadingTime,
                    y = g.setLoadEventEnd,
                    C = function(t, e) {
                        var n = performance.now();
                        return {
                            stop: bt(t, (function(t, r) {
                                e(t ? r - n : void 0)
                            })).stop
                        }
                    }(t, b).stop;

                function O() {
                    l += 1, t.notify(pt.VIEW_UPDATED, {
                        cumulativeLayoutShift: a,
                        documentVersion: l,
                        eventCounts: f,
                        id: c,
                        loadingTime: u,
                        loadingType: n,
                        location: p,
                        referrer: i,
                        startTime: o,
                        timings: d,
                        duration: (void 0 === s ? performance.now() : s) - o
                    })
                }
                return ne("layout-shift") ? (a = 0, E = function(t, e) {
                    return {
                        stop: t.subscribe(pt.PERFORMANCE_ENTRY_COLLECTED, (function(t) {
                            "layout-shift" !== t.entryType || t.hadRecentInput || e(t.value)
                        })).unsubscribe
                    }
                }(t, (function(t) {
                    a += t, v()
                })).stop) : E = W, O(), {
                    scheduleUpdate: v,
                    end: function() {
                        s = performance.now(), h(), C(), E()
                    },
                    isDifferentView: function(t) {
                        return p.pathname !== t.pathname || (e = t.hash, n = e.substr(1), !document.getElementById(n) && t.hash !== p.hash);
                        var e, n
                    },
                    triggerUpdate: function() {
                        T(), O()
                    },
                    updateTimings: function(t) {
                        d = t, void 0 !== t.loadEventEnd && y(t.loadEventEnd)
                    },
                    updateLocation: function(t) {
                        p = Object(r.a)({}, t)
                    },
                    get url() {
                        return p.href
                    }
                }
            }

            function sn(t, e, n) {
                return t.subscribe(pt.VIEW_UPDATED, (function(n) {
                    e.isEnabled("v2_format") ? t.notify(pt.RAW_RUM_EVENT_V2_COLLECTED, function(t) {
                        return {
                            rawRumEvent: {
                                _dd: {
                                    documentVersion: t.documentVersion
                                },
                                date: q(t.startTime),
                                type: vt.VIEW,
                                view: {
                                    action: {
                                        count: t.eventCounts.userActionCount
                                    },
                                    cumulativeLayoutShift: t.cumulativeLayoutShift,
                                    domComplete: P(t.timings.domComplete),
                                    domContentLoaded: P(t.timings.domContentLoaded),
                                    domInteractive: P(t.timings.domInteractive),
                                    error: {
                                        count: t.eventCounts.errorCount
                                    },
                                    firstContentfulPaint: P(t.timings.firstContentfulPaint),
                                    firstInputDelay: P(t.timings.firstInputDelay),
                                    largestContentfulPaint: P(t.timings.largestContentfulPaint),
                                    loadEventEnd: P(t.timings.loadEventEnd),
                                    loadingTime: P(t.loadingTime),
                                    loadingType: t.loadingType,
                                    longTask: {
                                        count: t.eventCounts.longTaskCount
                                    },
                                    resource: {
                                        count: t.eventCounts.resourceCount
                                    },
                                    timeSpent: P(t.duration)
                                }
                            },
                            startTime: t.startTime
                        }
                    }(n)) : t.notify(pt.RAW_RUM_EVENT_COLLECTED, function(t) {
                        return {
                            rawRumEvent: {
                                date: q(t.startTime),
                                duration: P(t.duration),
                                evt: {
                                    category: mt.VIEW
                                },
                                rum: {
                                    documentVersion: t.documentVersion
                                },
                                view: {
                                    loadingTime: P(t.loadingTime),
                                    loadingType: t.loadingType,
                                    measures: Object(r.a)(Object(r.a)({}, t.eventCounts), {
                                        domComplete: P(t.timings.domComplete),
                                        domContentLoaded: P(t.timings.domContentLoaded),
                                        domInteractive: P(t.timings.domInteractive),
                                        firstContentfulPaint: P(t.timings.firstContentfulPaint),
                                        loadEventEnd: P(t.timings.loadEventEnd)
                                    })
                                }
                            },
                            startTime: t.startTime
                        }
                    }(n))
                })), an(n, t)
            }
            var cn;

            function fn(t, e) {
                var n = fe(t.cookieOptions, "rum", (function(e) {
                    return function(t, e) {
                        var n;
                        n = function(t) {
                            return t === cn.NOT_TRACKED || t === cn.TRACKED_WITH_RESOURCES || t === cn.TRACKED_WITHOUT_RESOURCES
                        }(e) ? e : V(t.sampleRate) ? V(t.resourceSampleRate) ? cn.TRACKED_WITH_RESOURCES : cn.TRACKED_WITHOUT_RESOURCES : cn.NOT_TRACKED;
                        return {
                            trackingType: n,
                            isTracked: dn(n)
                        }
                    }(t, e)
                }));
                return n.renewObservable.subscribe((function() {
                    e.notify(pt.SESSION_RENEWED)
                })), {
                    getId: n.getId,
                    isTracked: function() {
                        return void 0 !== n.getId() && dn(n.getTrackingType())
                    },
                    isTrackedWithResource: function() {
                        return void 0 !== n.getId() && n.getTrackingType() === cn.TRACKED_WITH_RESOURCES
                    }
                }
            }

            function dn(t) {
                return t === cn.TRACKED_WITH_RESOURCES || t === cn.TRACKED_WITHOUT_RESOURCES
            }

            function ln(t, e) {
                var n = function(t, e) {
                    var n, r = o(t.rumEndpoint, (function() {
                            return e.notify(pt.BEFORE_UNLOAD)
                        })),
                        i = t.replica;
                    void 0 !== i && (n = o(i.rumEndpoint));

                    function o(e, n) {
                        return new v(new m(e, t.batchBytesLimit, !0), t.maxBatchSize, t.batchBytesLimit, t.maxMessageSize, t.flushTimeout, n)
                    }

                    function a(e) {
                        return s(e, t.isEnabled("v2_format") ? {
                            application: {
                                id: i.applicationId
                            }
                        } : {
                            application_id: i.applicationId
                        })
                    }
                    var u = !1;
                    return {
                        add: function(t) {
                            u || (r.add(t), n && n.add(a(t)))
                        },
                        stop: function() {
                            u = !0
                        },
                        upsert: function(t, e) {
                            u || (r.upsert(t, e), n && n.upsert(a(t), e))
                        }
                    }
                }(t, e);
                return e.subscribe(pt.RUM_EVENT_COLLECTED, (function(t) {
                    var e = t.rumEvent,
                        r = t.serverRumEvent;
                    e.evt.category === mt.VIEW ? n.upsert(r, e.view.id) : n.add(r)
                })), e.subscribe(pt.RUM_EVENT_V2_COLLECTED, (function(t) {
                    var e = t.rumEvent,
                        r = t.serverRumEvent;
                    e.type === vt.VIEW ? n.upsert(r, e.view.id) : n.add(r)
                })), {
                    stop: function() {
                        n.stop()
                    }
                }
            }! function(t) {
                t.NOT_TRACKED = "0", t.TRACKED_WITH_RESOURCES = "1", t.TRACKED_WITHOUT_RESOURCES = "2"
            }(cn || (cn = {}));
            var pn = {
                buildMode: "release",
                datacenter: "us",
                sdkVersion: "1.26.3"
            };
            var En, mn, vn, Tn, hn, gn, bn, yn, Cn, On, Rn, _n, Sn = (En = function(t, e) {
                var n = new Tt,
                    r = function(t, e) {
                        var n = ot(t, e);
                        return {
                            configuration: n,
                            internalMonitoring: R(n)
                        }
                    }(t, pn),
                    o = r.configuration,
                    a = r.internalMonitoring,
                    u = fn(o, n);
                a.setExternalContextProvider((function() {
                    return s({
                        application_id: t.applicationId
                    }, f.findView(), e())
                }));
                var c = function(t, e, n, r, i, o) {
                        var a = function(t, e) {
                                var n, r, i, o = [],
                                    a = [];
                                t.subscribe(pt.VIEW_CREATED, (function(t) {
                                    n && o.unshift({
                                        context: c(),
                                        endTime: t.startTime,
                                        startTime: n.startTime
                                    }), n = t, i = e.getId()
                                })), t.subscribe(pt.VIEW_UPDATED, (function(t) {
                                    n.id === t.id && (n = t)
                                })), t.subscribe(pt.AUTO_ACTION_CREATED, (function(t) {
                                    r = t
                                })), t.subscribe(pt.AUTO_ACTION_COMPLETED, (function(t) {
                                    r && a.unshift({
                                        context: f(),
                                        endTime: r.startTime + t.duration,
                                        startTime: r.startTime
                                    }), r = void 0
                                })), t.subscribe(pt.AUTO_ACTION_DISCARDED, (function() {
                                    r = void 0
                                })), t.subscribe(pt.SESSION_RENEWED, (function() {
                                    o = [], a = [], n = void 0, r = void 0
                                }));
                                var u = window.setInterval(_((function() {
                                    s(o, 144e5), s(a, 3e5)
                                })), 6e4);

                                function s(t, e) {
                                    for (var n = performance.now() - e; t.length > 0 && t[t.length - 1].startTime < n;) t.pop()
                                }

                                function c() {
                                    return {
                                        sessionId: i,
                                        view: {
                                            id: n.id,
                                            referrer: n.referrer,
                                            url: n.location.href
                                        }
                                    }
                                }

                                function f() {
                                    return {
                                        userAction: {
                                            id: r.id
                                        }
                                    }
                                }

                                function d(t, e, n, r) {
                                    if (void 0 === r) return n ? t() : void 0;
                                    if (n && r >= n.startTime) return t();
                                    for (var i = 0, o = e; i < o.length; i++) {
                                        var a = o[i];
                                        if (r > a.endTime) break;
                                        if (r >= a.startTime) return a.context
                                    }
                                }
                                var l = {
                                    findAction: function(t) {
                                        return d(f, a, r, t)
                                    },
                                    findActionV2: function(t) {
                                        var e = l.findAction(t);
                                        if (e) return {
                                            action: {
                                                id: e.userAction.id
                                            }
                                        }
                                    },
                                    findView: function(t) {
                                        return d(c, o, n, t)
                                    },
                                    findViewV2: function(t) {
                                        var e = l.findView(t);
                                        if (e) return {
                                            session: {
                                                id: e.sessionId
                                            },
                                            view: e.view
                                        }
                                    },
                                    stop: function() {
                                        window.clearInterval(u)
                                    }
                                };
                                return l
                            }(n, i),
                            u = ln(r, n);
                        se(t, r, n, i, a, o), ce(t, r, n, i, a, o),
                            function(t, e) {
                                t.subscribe(pt.PERFORMANCE_ENTRY_COLLECTED, (function(n) {
                                    if ("longtask" === n.entryType)
                                        if (e.isEnabled("v2_format")) {
                                            var r = {
                                                date: q(n.startTime),
                                                longTask: {
                                                    duration: P(n.duration)
                                                },
                                                type: vt.LONG_TASK
                                            };
                                            t.notify(pt.RAW_RUM_EVENT_V2_COLLECTED, {
                                                rawRumEvent: r,
                                                startTime: n.startTime
                                            })
                                        } else r = {
                                            date: q(n.startTime),
                                            duration: P(n.duration),
                                            evt: {
                                                category: mt.LONG_TASK
                                            }
                                        }, t.notify(pt.RAW_RUM_EVENT_COLLECTED, {
                                            rawRumEvent: r,
                                            startTime: n.startTime
                                        })
                                }))
                            }(n, r), Qe(n, r, i), sn(n, r, e);
                        var s = ze(n, r).addError;
                        return {
                            addAction: We(n, r).addAction,
                            addError: s,
                            parentContexts: a,
                            stop: function() {
                                u.stop()
                            }
                        }
                    }(t.applicationId, location, n, o, u, e),
                    f = c.parentContexts,
                    d = c.addError,
                    l = c.addAction;
                return Ve(n, o), re(n, o), xt(n), {
                    addAction: l,
                    addError: d,
                    getInternalContext: function(t, e, n, r) {
                        return {
                            get: function(o) {
                                if (r.isEnabled("v2_format")) {
                                    var a = n.findViewV2(o);
                                    if (e.isTracked() && a && a.session.id) {
                                        var u = n.findActionV2(o);
                                        return i(s({
                                            applicationId: t
                                        }, {
                                            sessionId: a.session.id,
                                            view: a.view
                                        }, u ? {
                                            userAction: {
                                                id: u.action.id
                                            }
                                        } : void 0))
                                    }
                                } else if (a = n.findView(o), e.isTracked() && a && a.sessionId) return i(s({
                                    applicationId: t
                                }, a, n.findAction(o)))
                            }
                        }
                    }(t.applicationId, u, f, o).get
                }
            }, mn = !1, _n = {}, vn = {
                get: function() {
                    return _n
                },
                add: function(t, e) {
                    _n[t] = e
                },
                remove: function(t) {
                    delete _n[t]
                },
                set: function(t) {
                    _n = t
                }
            }, Tn = function() {}, hn = new Et, gn = function(t) {
                hn.add([t, c(vn.get())])
            }, bn = new Et, yn = function(t) {
                bn.add([t, c(vn.get())])
            }, On = {
                init: _((function(t) {
                    var e;
                    dt(at(t)) && lt() && function(t) {
                        return mn ? (t.silentMultipleInit || console.error("DD_RUM is already initialized."), !1) : t && (t.clientToken || t.publicApiKey) ? t.applicationId ? void 0 === t.sampleRate || F(t.sampleRate) ? void 0 === t.resourceSampleRate || F(t.resourceSampleRate) ? !Array.isArray(t.allowedTracingOrigins) || 0 === t.allowedTracingOrigins.length || void 0 !== t.service || (console.error("Service need to be configured when tracing is enabled"), !1) : (console.error("Resource Sample Rate should be a number between 0 and 100"), !1) : (console.error("Sample Rate should be a number between 0 and 100"), !1) : (console.error("Application ID is not configured, no RUM data will be collected."), !1) : (console.error("Client Token is not configured, we will not send any data."), !1)
                    }(t) && (t.publicApiKey && (t.clientToken = t.publicApiKey), e = En(t, vn.get), gn = e.addAction, yn = e.addError, Tn = e.getInternalContext, hn.drain((function(t) {
                        var e = t[0],
                            n = t[1];
                        return gn(e, n)
                    })), bn.drain((function(t) {
                        var e = t[0],
                            n = t[1];
                        return yn(e, n)
                    })), mn = !0)
                })),
                addRumGlobalContext: _(vn.add),
                removeRumGlobalContext: _(vn.remove),
                getRumGlobalContext: _(vn.get),
                setRumGlobalContext: _(vn.set),
                getInternalContext: _((function(t) {
                    return Tn(t)
                })),
                addAction: _((function(t, e) {
                    gn({
                        name: t,
                        context: c(e),
                        startTime: performance.now(),
                        type: _t.CUSTOM
                    })
                })),
                addUserAction: function(t, e) {
                    Cn.addAction(t, e)
                },
                addError: _((function(t, e, n) {
                    var r;
                    void 0 === n && (n = o.CUSTOM), n === o.CUSTOM || n === o.NETWORK || n === o.SOURCE ? r = n : (console.error("DD_RUM.addError: Invalid source '" + n + "'"), r = o.CUSTOM), yn({
                        error: t,
                        context: c(e),
                        source: r,
                        startTime: performance.now()
                    })
                }))
            }, Rn = Object(r.a)(Object(r.a)({}, On), {
                onReady: function(t) {
                    t()
                }
            }), Object.defineProperty(Rn, "_setDebug", {
                get: function() {
                    return I
                },
                enumerable: !1
            }), Cn = Rn);
            ! function(t, e, n) {
                var r = t[e];
                t[e] = n, r && r.q && r.q.forEach((function(t) {
                    return t()
                }))
            }(function() {
                if ("object" == typeof globalThis) return globalThis;
                Object.defineProperty(Object.prototype, "_dd_temp_", {
                    get: function() {
                        return this
                    },
                    configurable: !0
                });
                var t = _dd_temp_;
                return delete Object.prototype._dd_temp_, "object" != typeof t && (t = "object" == typeof self ? self : "object" == typeof window ? window : {}), t
            }(), "DD_RUM", Sn), n.d(e, "Datacenter", (function() {
                return nt
            })), n.d(e, "ErrorSource", (function() {
                return o
            })), n.d(e, "datadogRum", (function() {
                return Sn
            })), n.d(e, "RumEventCategory", (function() {
                return mt
            }))
        }
    }
]);