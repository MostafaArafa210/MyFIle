/* eslint-disable no-undef */
const globalDefaults = {
    awsUrl: 'https://qyqn3khvrh.execute-api.us-west-2.amazonaws.com/dev',
};
const getTargetEnvironmentListForType = () =>
    Object.keys(environments)
    .filter((environment) => environment.startsWith(process.ENVIRONMENT_TYPE))
    .map((environment) => ({ ...environments[environment],
        environmentKey: environment
    }));
const getAllApprovedOAuthOrigins = () => [
    'https://my.cloudelements.co.uk',
    'https://my-snapshot.cloudelements.io',
    'https://my.snap0.cloudelements.io',
    'https://my-staging.cloudelements.io',
    'https://my.stage0.cloudelements.io',
    'https://my.es-euwest-stage-0.aws-euws.cloudelements.app',
    'https://my.es-uswest-alpha-0.aws-uswa.cloudelements.app',
    'https://my.apac.cloudelements.io',
    'https://my.es-eunorth-prod-0.aws-eunp.cloudelements.app',
    'https://my.es-useast-prod-0.aws-usep.cloudelements.app',
    'https://my.es-jpeast-prod-0.aws-jpep.cloudelements.app',
    'https://my.es-aueast-prod-0.aws-auep.cloudelements.app',
    'https://my.es-apacsoutheast-prod-0.aws-apsep.cloudelements.app',
    'https://my.cloudelements.io',
    'https://my.apac.cloudelements.io',
    'http://localhost:8111',
    'https://my-localhost.cloudelements.io',
    'https://my-qa.cloudelements.io',
    'https://my-ibm.cloud-elements.com',
    'https://my.openconnectors.ext.int.sap.hana.ondemand.com',
    'https://my.openconnectors.ext.hanatrial.ondemand.com',
    'https://my.openconnectors.us2.ext.hana.ondemand.com',
    'https://my.openconnectors.us4.ext.hana.ondemand.com',
    'https://my.openconnectors.us10.ext.hana.ondemand.com',
    'https://my.openconnectors.us20.ext.hana.ondemand.com',
    'https://my.openconnectors.us21.ext.hana.ondemand.com',
    'https://my.openconnectors.us30.ext.hana.ondemand.com',
    'https://my.openconnectors.ca10.ext.hana.ondemand.com',
    'https://my.openconnectors.br10.ext.hana.ondemand.com',
    'https://my.openconnectors.ext.hana.ondemand.com',
    'https://my.openconnectors.eu2.ext.hana.ondemand.com',
    'https://my.openconnectors.eu3.ext.hana.ondemand.com',
    'https://my.openconnectors.eu10.ext.hana.ondemand.com',
    'https://my.openconnectors.eu11.ext.hana.ondemand.com',
    'https://my.openconnectors.eu12.ext.hana.ondemand.com',
    'https://my.openconnectors.eu20.ext.hana.ondemand.com',
    'https://my.openconnectors.eu30.ext.hana.ondemand.com',
    'https://my.openconnectors.jp20.ext.hana.ondemand.com',
    'https://my.openconnectors.jp10.ext.hana.ondemand.com',
    'https://my.openconnectors.ap10.ext.hana.ondemand.com',
    'https://my.openconnectors.ap10s.ext.hana.ondemand.com',
    'https://my.openconnectors.ap11.ext.hana.ondemand.com',
    'https://my.openconnectors.ap12.ext.hana.ondemand.com',
    'https://my.openconnectors.ap20.ext.hana.ondemand.com',
    'https://my.openconnectors.ap21.ext.hana.ondemand.com',
    'https://my.openconnectors.in30.ext.hana.ondemand.com',
    'https://my.openconnectors.trial.ap21.ext.hana.ondemand.com',
    'https://my.openconnectors.trial.eu10.ext.hana.ondemand.com',
    'https://my.openconnectors.trial.eu20.ext.hana.ondemand.com',
    'https://my.openconnectors.trial.us30.ext.hana.ondemand.com',
    'https://my.openconnectors.trial.us10.ext.hana.ondemand.com',
    'https://ib.platform.axwaytest.net', // Axway US Prod
    'https://ib.platform.axway.com', // Axway US Prod
    'https://ib.us.axwaytest.net', // Axway US Prod
    'https://ib.us.axway.com', // Axway US Prod
    'https://ib.eu.axwaytest.net', // Axway UE Prod
    'https://ib.eu.axway.com', // Axway EU Prod
    'https://sandbox-ib.platform.axwaytest.net', // Axway Staging
    'https://sandbox-ib.platform.axway.com', // Axway Staging
    'https://sandbox-ib.us.axwaytest.net', // Axway Staging
    'https://sandbox-ib.us-2.axwaytest.net', // Axway Staging
    'https://sandbox-ib.us.axway.com', // Axway Staging
    'https://sandbox-ib.us-2.axway.com', // Axway Staging
    'https://us-staging.integrate.sugarapps.com',
    'https://us.integrate.sugarapps.com',
    'https://ie.integrate.sugarapps.com',
    'https://au.integrate.sugarapps.com',
];
const getAllApprovedOauthResponders = () => [
    'https://auth.cloudelements.io',
    'https://auth.cloudelements.co.uk',
    'https://my-ibm.cloud-elements.com',
    'https://my-qa.cloudelements.io',
    'https://auth.es-eunorth-prod-0.aws-eunp.cloudelements.app',
    'https://auth.openconnectors.ext.int.sap.hana.ondemand.com',
    'https://auth.openconnectors.ext.hanatrial.ondemand.com',
    'https://auth.openconnectors.us2.ext.hana.ondemand.com',
    'https://auth.openconnectors.us4.ext.hana.ondemand.com',
    'https://auth.openconnectors.us10.ext.hana.ondemand.com',
    'https://auth.openconnectors.us20.ext.hana.ondemand.com',
    'https://auth.openconnectors.us21.ext.hana.ondemand.com',
    'https://auth.openconnectors.us30.ext.hana.ondemand.com',
    'https://auth.openconnectors.ca10.ext.hana.ondemand.com',
    'https://auth.openconnectors.br10.ext.hana.ondemand.com',
    'https://auth.openconnectors.ext.hana.ondemand.com',
    'https://auth.openconnectors.eu2.ext.hana.ondemand.com',
    'https://auth.openconnectors.eu3.ext.hana.ondemand.com',
    'https://auth.openconnectors.eu10.ext.hana.ondemand.com',
    'https://auth.openconnectors.eu11.ext.hana.ondemand.com',
    'https://auth.openconnectors.eu12.ext.hana.ondemand.com',
    'https://auth.openconnectors.eu20.ext.hana.ondemand.com',
    'https://auth.openconnectors.eu30.ext.hana.ondemand.com',
    'https://auth.openconnectors.jp20.ext.hana.ondemand.com',
    'https://auth.openconnectors.jp10.ext.hana.ondemand.com',
    'https://auth.openconnectors.ap10.ext.hana.ondemand.com',
    'https://auth.openconnectors.ap10s.ext.hana.ondemand.com',
    'https://auth.openconnectors.ap11.ext.hana.ondemand.com',
    'https://auth.openconnectors.ap12.ext.hana.ondemand.com',
    'https://auth.openconnectors.ap20.ext.hana.ondemand.com',
    'https://auth.openconnectors.ap21.ext.hana.ondemand.com',
    'https://auth.openconnectors.in30.ext.hana.ondemand.com',
    'https://my.openconnectors.ext.hanatrial.ondemand.com',
    'https://my.openconnectors.trial.ap21.ext.hana.ondemand.com',
    'https://my.openconnectors.trial.eu10.ext.hana.ondemand.com',
    'https://my.openconnectors.trial.eu12.ext.hana.ondemand.com',
    'https://my.openconnectors.trial.eu20.ext.hana.ondemand.com',
    'https://my.openconnectors.trial.us30.ext.hana.ondemand.com',
    'https://my.openconnectors.trial.us10.ext.hana.ondemand.com',
    'https://ib.platform.axwaytest.net', // Axway US Prod
    'https://ib.platform.axway.com', // Axway US Prod
    'https://ib.us.axwaytest.net', // Axway US Prod
    'https://ib.us.axway.com', // Axway US Prod
    'https://ib.eu.axwaytest.net', // Axway UE Prod
    'https://ib.eu.axway.com', // Axway EU Prod
    'https://sandbox-ib.platform.axwaytest.net', // Axway Staging
    'https://sandbox-ib.platform.axway.com', // Axway Staging
    'https://sandbox-ib.us.axwaytest.net', // Axway Staging
    'https://sandbox-ib.us-2.axwaytest.net', // Axway Staging
    'https://sandbox-ib.us.axway.com', // Axway Staging
    'https://sandbox-ib.us-2.axway.com', // Axway Staging
    'https://auth-us-staging.integrate.sugarapps.com',
    'https://auth-us.integrate.sugarapps.com',
    'https://auth-ie.integrate.sugarapps.com',
    'https://auth-au.integrate.sugarapps.com',
];
const buildSkeletorEnvConfig = () => {
    console.log(`Looking up skeletor environment config for SKELETOR_ENV: ${process.SKELETOR_ENV}`);
    switch (process.SKELETOR_ENV) {
        case 'production':
            return {
                redirectUrl: 'https://my.cloudelements.io/login',
                navigationBackUrl: 'https://my.cloudelements.io/welcome',
                github: {
                    clientId: 'f2626f2ac85afc240bf6',
                    analyticsId: 'UA-88852446-1',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'material',
            };
        case 'production-uk':
            return {
                redirectUrl: 'https://my.cloudelements.co.uk/login',
                navigationBackUrl: 'https://my.cloudelements.co.uk/welcome',
                github: {
                    clientId: '9d28113d2d9a1338acc3',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'material',
            };
        case 'staging':
            return {
                redirectUrl: 'https://my-staging.cloudelements.io/login',
                navigationBackUrl: 'https://my-staging.cloudelements.io/welcome',
                github: {
                    clientId: 'e5ded980403aab91009a',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'material',
            };
        case 'stage0':
            return {
                redirectUrl: 'https://my.stage0.cloudelements.io/login',
                navigationBackUrl: 'https://my.stage0.cloudelements.io/welcome',
                github: {
                    clientId: 'e5ded980403aab91009a',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'material',
            };
        case 'es-euwest-stage-0':
            return {
                redirectUrl: 'https://my.es-euwest-stage-0.aws-euws.cloudelements.app/login',
                navigationBackUrl: 'https:/my.es-euwest-stage-0.aws-euws.cloudelements.app/welcome',
                github: {
                    clientId: 'a707e7570533a8392a03', //owned by "elementsbot <cebot-github@uipath.com>"
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'material',
            };
        case 'es-uswest-alpha-0':
            return {
                redirectUrl: 'https://my.es-uswest-alpha-0.aws-uswa.cloudelements.app/login',
                navigationBackUrl: 'https://my.es-uswest-alpha-0.aws-uswa.cloudelements.app/welcome',
                github: {
                    clientId: 'a0a97e62d6cb694be8a8',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'material',
            };
        case 'es-eunorth-prod-0':
            return {
                redirectUrl: 'https://my.es-eunorth-prod-0.aws-eunp.cloudelements.app/login',
                navigationBackUrl: 'https:/my.es-eunorth-prod-0.aws-eunp.cloudelements.app/welcome',
                github: {
                    clientId: '237cd5235e8982744157', //owned by "elementsbot <cebot-github@uipath.com>"
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'material',
            };
        case 'es-useast-prod-0':
            return {
                redirectUrl: 'https://my.es-useast-prod-0.aws-usep.cloudelements.app/login',
                navigationBackUrl: 'https://my.es-useast-prod-0.aws-usep.cloudelements.app/welcome',
                github: {
                    clientId: '2d9c1d6bee3502d0f058', //owned by "elementsbot <cebot-github@uipath.com>"
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'material',
            };
        case 'es-jpeast-prod-0':
            return {
                redirectUrl: 'https://my.es-jpeast-prod-0.aws-jpep.cloudelements.app/login',
                navigationBackUrl: 'https://my.es-jpeast-prod-0.aws-jpep.cloudelements.app/welcome',
                github: {
                    clientId: 'de4391ef2be55a8a48c7', //owned by "elementsbot <cebot-github@uipath.com>"
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'material',
            };
        case 'es-aueast-prod-0':
            return {
                redirectUrl: 'https://my.es-aueast-prod-0.aws-auep.cloudelements.app/login',
                navigationBackUrl: 'https://my.es-aueast-prod-0.aws-auep.cloudelements.app/welcome',
                github: {
                    clientId: '021fdcf92777f48f6ba2', //owned by "elementsbot <cebot-github@uipath.com>"
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'material',
            };
        case 'es-apacsoutheast-prod-0':
            return {
                redirectUrl: 'https://my.es-apacsoutheast-prod-0.aws-apsep.cloudelements.app/login',
                navigationBackUrl: 'https://my.es-apacsoutheast-prod-0.aws-apsep.cloudelements.app/welcome',
                github: {
                    clientId: '01a0ae1450e3d2c2862b', //owned by "elementsbot <cebot-github@uipath.com>"
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'material',
            };
        case 'apac0':
            return {
                redirectUrl: 'https://my.apac.cloudelements.io/login',
                navigationBackUrl: 'https://my.apac.cloudelements.io/welcome',
                github: {
                    clientId: 'fc8b5e6cf7edc782269c',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'material',
            };
        case 'snapshot':
            return {
                redirectUrl: 'https://my-snapshot.cloudelements.io/login',
                navigationBackUrl: 'https://my-snapshot.cloudelements.io/welcome',
                github: {
                    clientId: '0af766fc76e46d4da681',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'material',
            };
        case 'snap0':
            return {
                redirectUrl: 'https://my.snap0.cloudelements.io/login',
                navigationBackUrl: 'https://my.snap0.cloudelements.io/welcome',
                github: {
                    clientId: '0af766fc76e46d4da681',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'material',
            };
        case 'dev-localhost':
            return {
                redirectUrl: 'https://my-localhost.cloudelements.io/login',
                navigationBackUrl: 'https://my-localhost.cloudelements.io/welcome',
                github: {
                    clientId: 'OAUTH_NOT_CURRENTLY_SUPPORTED_FROM_HERE',
                },
                google: {
                    clientId: 'OAUTH_NOT_CURRENTLY_SUPPORTED_FROM_HERE',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'material',
                title: 'Cloud Elements',
            };
        case 'ibm-bluemix':
            return {
                redirectUrl: 'https://my-ibm.cloud-elements.com/login',
                navigationBackUrl: 'https://my-ibm.cloud-elements.com/welcome',
                github: {
                    clientId: 'OAUTH_NOT_CURRENTLY_SUPPORTED_FROM_HERE',
                },
                google: {
                    clientId: 'OAUTH_NOT_CURRENTLY_SUPPORTED_FROM_HERE',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'material',
                title: 'Cloud Elements',
            };
        case 'sap-snapshot':
            return {
                redirectUrl: 'https://my.openconnectors.ext.int.sap.hana.ondemand.com/login',
                navigationBackUrl: 'https://my.openconnectors.ext.int.sap.hana.ondemand.com/welcome',
                github: {
                    clientId: '0af766fc76e46d4da681',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'ui5',
                title: 'Open Connectors',
            };
        case 'sap-ext-trial':
            return {
                redirectUrl: 'https://my.openconnectors.ext.hanatrial.ondemand.com/login',
                navigationBackUrl: 'https://my.openconnectors.ext.hanatrial.ondemand.com/welcome',
                github: {
                    clientId: 'e5ded980403aab91009a',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'ui5',
                title: 'Open Connectors',
            };
        case 'sap-us2-ext':
            return {
                redirectUrl: 'https://my.openconnectors.us2.ext.hana.ondemand.com/login',
                navigationBackUrl: 'https://my.openconnectors.us2.ext.hana.ondemand.com/welcome',
                github: {
                    clientId: 'f2626f2ac85afc240bf6',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'ui5',
                title: 'Open Connectors',
            };
        case 'sap-us4-ext':
            return {
                redirectUrl: 'https://my.openconnectors.us4.ext.hana.ondemand.com/login',
                navigationBackUrl: 'https://my.openconnectors.us4.ext.hana.ondemand.com/welcome',
                github: {
                    clientId: '9d28113d2d9a1338acc3',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                ui: 'ui5',
                title: 'Open Connectors',
            };
        case 'sap-us10-ext':
            return {
                redirectUrl: 'https://my.openconnectors.us10.ext.hana.ondemand.com/login',
                navigationBackUrl: 'https://my.openconnectors.us10.ext.hana.ondemand.com/welcome',
                github: {
                    clientId: '9d28113d2d9a1338acc3',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'ui5',
                title: 'Open Connectors',
            };
        case 'sap-us20-ext':
            return {
                redirectUrl: 'https://my.openconnectors.us20.ext.hana.ondemand.com/login',
                navigationBackUrl: 'https://my.openconnectors.us20.ext.hana.ondemand.com/welcome',
                github: {
                    clientId: '9d28113d2d9a1338acc3',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'ui5',
                title: 'Open Connectors',
            };
        case 'sap-us21-ext':
            return {
                redirectUrl: 'https://my.openconnectors.us21.ext.hana.ondemand.com/login',
                navigationBackUrl: 'https://my.openconnectors.us21.ext.hana.ondemand.com/welcome',
                github: {
                    clientId: '9d28113d2d9a1338acc3',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'ui5',
                title: 'Open Connectors',
            };
        case 'sap-us30-ext':
            return {
                redirectUrl: 'https://my.openconnectors.us30.ext.hana.ondemand.com/login',
                navigationBackUrl: 'https://my.openconnectors.us30.ext.hana.ondemand.com/welcome',
                github: {
                    clientId: '9d28113d2d9a1338acc3',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'ui5',
                title: 'Open Connectors',
            };
        case 'sap-ca10-ext':
            return {
                redirectUrl: 'https://my.openconnectors.ca10.ext.hana.ondemand.com/login',
                navigationBackUrl: 'https://my.openconnectors.ca10.ext.hana.ondemand.com/welcome',
                github: {
                    clientId: '9d28113d2d9a1338acc3',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'ui5',
                title: 'Open Connectors',
            };
        case 'sap-br10-ext':
            return {
                redirectUrl: 'https://my.openconnectors.br10.ext.hana.ondemand.com/login',
                navigationBackUrl: 'https://my.openconnectors.br10.ext.hana.ondemand.com/welcome',
                github: {
                    clientId: '9d28113d2d9a1338acc3',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'ui5',
                title: 'Open Connectors',
            };
        case 'sap-eu-ext':
            return {
                redirectUrl: 'https://my.openconnectors.ext.hana.ondemand.com/login',
                navigationBackUrl: 'https://my.openconnectors.ext.hana.ondemand.com/welcome',
                github: {
                    clientId: '9d28113d2d9a1338acc3',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'ui5',
                title: 'Open Connectors',
            };
        case 'sap-eu2-ext':
            return {
                redirectUrl: 'https://my.openconnectors.eu2.ext.hana.ondemand.com/login',
                navigationBackUrl: 'https://my.openconnectors.eu2.ext.hana.ondemand.com/welcome',
                github: {
                    clientId: '9d28113d2d9a1338acc3',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'ui5',
                title: 'Open Connectors',
            };
        case 'sap-eu3-ext':
            return {
                redirectUrl: 'https://my.openconnectors.eu3.ext.hana.ondemand.com/login',
                navigationBackUrl: 'https://my.openconnectors.eu3.ext.hana.ondemand.com/welcome',
                github: {
                    clientId: '9d28113d2d9a1338acc3',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'ui5',
                title: 'Open Connectors',
            };
        case 'sap-eu10-ext':
            return {
                redirectUrl: 'https://my.openconnectors.eu10.ext.hana.ondemand.com/login',
                navigationBackUrl: 'https://my.openconnectors.eu10.ext.hana.ondemand.com/welcome',
                github: {
                    clientId: '9d28113d2d9a1338acc3',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'ui5',
                title: 'Open Connectors',
            };
        case 'sap-eu11-ext':
            return {
                redirectUrl: 'https://my.openconnectors.eu11.ext.hana.ondemand.com/login',
                navigationBackUrl: 'https://my.openconnectors.eu11.ext.hana.ondemand.com/welcome',
                github: {
                    clientId: '9d28113d2d9a1338acc3',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'ui5',
                title: 'Open Connectors',
            };
        case 'sap-eu12-ext':
            return {
                redirectUrl: 'https://my.openconnectors.eu12.ext.hana.ondemand.com/login',
                navigationBackUrl: 'https://my.openconnectors.eu12.ext.hana.ondemand.com/welcome',
                github: {
                    clientId: '9d28113d2d9a1338acc3',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'ui5',
                title: 'Open Connectors',
            };
        case 'sap-eu20-ext':
            return {
                redirectUrl: 'https://my.openconnectors.eu20.ext.hana.ondemand.com/login',
                navigationBackUrl: 'https://my.openconnectors.eu20.ext.hana.ondemand.com/welcome',
                github: {
                    clientId: '9d28113d2d9a1338acc3',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'ui5',
                title: 'Open Connectors',
            };
        case 'sap-eu30-ext':
            return {
                redirectUrl: 'https://my.openconnectors.eu30.ext.hana.ondemand.com/login',
                navigationBackUrl: 'https://my.openconnectors.eu30.ext.hana.ondemand.com/welcome',
                github: {
                    clientId: '9d28113d2d9a1338acc3',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'ui5',
                title: 'Open Connectors',
            };
        case 'sap-jp20-ext':
            return {
                redirectUrl: 'https://my.openconnectors.jp20.ext.hana.ondemand.com/login',
                navigationBackUrl: 'https://my.openconnectors.jp20.ext.hana.ondemand.com/welcome',
                github: {
                    clientId: '9d28113d2d9a1338acc3',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'ui5',
                title: 'Open Connectors',
            };
        case 'sap-jp10-ext':
            return {
                redirectUrl: 'https://my.openconnectors.jp10.ext.hana.ondemand.com/login',
                navigationBackUrl: 'https://my.openconnectors.jp10.ext.hana.ondemand.com/welcome',
                github: {
                    clientId: '9d28113d2d9a1338acc3',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'ui5',
                title: 'Open Connectors',
            };
        case 'sap-ap10-ext':
            return {
                redirectUrl: 'https://my.openconnectors.ap10.ext.hana.ondemand.com/login',
                navigationBackUrl: 'https://my.openconnectors.ap10.ext.hana.ondemand.com/welcome',
                github: {
                    clientId: '9d28113d2d9a1338acc3',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'ui5',
                title: 'Open Connectors',
            };
        case 'sap-ap10s-ext':
            return {
                redirectUrl: 'https://my.openconnectors.ap10s.ext.hana.ondemand.com/login',
                navigationBackUrl: 'https://my.openconnectors.ap10s.ext.hana.ondemand.com/welcome',
                github: {
                    clientId: 'fc8b5e6cf7edc782269c',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'ui5',
                title: 'Open Connectors',
            };
        case 'sap-ap11-ext':
            return {
                redirectUrl: 'https://my.openconnectors.ap11.ext.hana.ondemand.com/login',
                navigationBackUrl: 'https://my.openconnectors.ap11.ext.hana.ondemand.com/welcome',
                github: {
                    clientId: '9d28113d2d9a1338acc3',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'ui5',
                title: 'Open Connectors',
            };
        case 'sap-ap12-ext':
            return {
                redirectUrl: 'https://my.openconnectors.ap12.ext.hana.ondemand.com/login',
                navigationBackUrl: 'https://my.openconnectors.ap12.ext.hana.ondemand.com/welcome',
                github: {
                    clientId: 'fc8b5e6cf7edc782269c',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'ui5',
                title: 'Open Connectors',
            };
        case 'sap-ap20-ext':
            return {
                redirectUrl: 'https://my.openconnectors.ap20.ext.hana.ondemand.com/login',
                navigationBackUrl: 'https://my.openconnectors.ap20.ext.hana.ondemand.com/welcome',
                github: {
                    clientId: 'fc8b5e6cf7edc782269c',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'ui5',
                title: 'Open Connectors',
            };
        case 'sap-ap21-ext':
            return {
                redirectUrl: 'https://my.openconnectors.ap21.ext.hana.ondemand.com/login',
                navigationBackUrl: 'https://my.openconnectors.ap21.ext.hana.ondemand.com/welcome',
                github: {
                    clientId: '9d28113d2d9a1338acc3',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'ui5',
                title: 'Open Connectors',
            };
        case 'sap-in30-ext':
            return {
                redirectUrl: 'https://my.openconnectors.in30.ext.hana.ondemand.com/login',
                navigationBackUrl: 'https://my.openconnectors.in30.ext.hana.ondemand.com/welcome',
                github: {
                    clientId: 'fc8b5e6cf7edc782269c',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'ui5',
                title: 'Open Connectors',
            };
        case 'sap-trial-ap21-ext':
            return {
                redirectUrl: 'https://my.openconnectors.trial.ap21.ext.hana.ondemand.com/login',
                github: {
                    clientId: '9d28113d2d9a1338acc3',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'ui5',
                title: 'Open Connectors',
            };
        case 'sap-trial-eu10-ext':
            return {
                redirectUrl: 'https://my.openconnectors.trial.eu10.ext.hana.ondemand.com/login',
                navigationBackUrl: 'https://my.openconnectors.trial.eu10.ext.hana.ondemand.com/welcome',
                github: {
                    clientId: '9d28113d2d9a1338acc3',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'ui5',
                title: 'Open Connectors',
            };
        case 'sap-trial-eu20-ext':
            return {
                redirectUrl: 'https://my.openconnectors.trial.eu20.ext.hana.ondemand.com/login',
                navigationBackUrl: 'https://my.openconnectors.trial.eu20.ext.hana.ondemand.com/welcome',
                github: {
                    clientId: '9d28113d2d9a1338acc3',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'ui5',
                title: 'Open Connectors',
            };
        case 'sap-trial-us30-ext':
            return {
                redirectUrl: 'https://my.openconnectors.trial.us30.ext.hana.ondemand.com/login',
                navigationBackUrl: 'https://my.openconnectors.trial.us30.ext.hana.ondemand.com/welcome',
                github: {
                    clientId: '9d28113d2d9a1338acc3',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'ui5',
                title: 'Open Connectors',
            };
        case 'sap-trial-us10-ext':
            return {
                redirectUrl: 'https://my.openconnectors.trial.us10.ext.hana.ondemand.com/login',
                navigationBackUrl: 'https://my.openconnectors.trial.us10.ext.hana.ondemand.com/welcome',
                github: {
                    clientId: '9d28113d2d9a1338acc3',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'ui5',
                title: 'Open Connectors',
            };
        case 'sugar-us-staging':
            return {
                redirectUrl: 'https://us-staging.integrate.sugarapps.com/login',
                navigationBackUrl: 'https://us-staging.integrate.sugarapps.com/welcome',
                // These are from CE US Staging
                github: {
                    clientId: 'e5ded980403aab91009a',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'material',
                title: 'Sugar Integrate',
            };
        case 'sugar-us-production':
            return {
                redirectUrl: 'https://us.integrate.sugarapps.com/login',
                navigationBackUrl: 'https://us.integrate.sugarapps.com/welcome',
                // These are from CE UK Prod
                github: {
                    clientId: 'f2626f2ac85afc240bf6',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'material',
                title: 'Sugar Integrate',
            };
        case 'sugar-ie-production':
            return {
                redirectUrl: 'https://ie.integrate.sugarapps.com/login',
                navigationBackUrl: 'https://ie.integrate.sugarapps.com/welcome',
                // These are from CE US Prod
                github: {
                    clientId: '9d28113d2d9a1338acc3',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'material',
                title: 'Sugar Integrate',
            };
        case 'sugar-au-production':
            return {
                redirectUrl: 'https://au.integrate.sugarapps.com/login',
                navigationBackUrl: 'https://au.integrate.sugarapps.com/welcome',
                // These are from CE US Prod
                github: {
                    clientId: 'fc8b5e6cf7edc782269c',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'material',
                title: 'Sugar Integrate',
            };
        case 'localhost':
        default:
            return {
                redirectUrl: 'http://localhost:8111/login',
                navigationBackUrl: 'http://localhost:8111/welcome',
                github: {
                    clientId: 'ada4f15940313516eb89',
                },
                google: {
                    clientId: '139006665650-8lpupfts8lgaob2on9mb8988aod3rulh.apps.googleusercontent.com',
                    analyticsId: 'UA-88852446-1',
                },
                communityUrl: 'https://api.github.com/repos/CloudElementsOpenLabs',
                ui: 'material',
                title: 'Cloud Elements',
            };
    }
};
const buildSobaEnvConfig = (skeletorEnv, production) => {
    // The list of origins allowed to post messages to the OAuth component for each environment
    // Most environments use auth.cloudelements.io which is part of the production build
    const approvedOAuthOrigins = getAllApprovedOAuthOrigins();
    // A list of origins allowed to respond to the OAuth message
    const approvedOauthResponders = getAllApprovedOauthResponders();

    const defaults = {
        ...skeletorEnv,
        awsUrl: process.AWS_URL,
        production,
        intercomId: 'pq50auuw',
        staticUrl: '/assets',
        LDClientId: '592ef8c4c38c010a45847f5c',
        datadogToken: 'pub8637951af436ecaf2dcc4455d51ef154',
        imageHost: 'images.cloudelements.io',
        elementImages: process.Element_Image_List,
        approvedOAuthOrigins: [],
        approvedOauthResponders,
        zendeskWidgetHost: 'cloudelements.zendesk.com',
    };

    const usProductionDefaults = {
        ...defaults,
        approvedOAuthOrigins,
        auth0Domain: 'cloudelements.auth0.com',
        auth0ClientId: '4c2WoJQ5rFi9WzF958Cz4BANyp1CtHTT',
        ceEnv: 'prd0-aws-usw2',
        ceUrl: 'https://api.cloud-elements.com',
    };

    const euProductionDefaults = {
        ...defaults,
        imageHost: ['images.cloudelements.co.uk', 'images.cloudelements.io'],
        auth0Domain: 'cloudelements.eu.auth0.com',
        auth0ClientId: 'XlABBcVXP8SNE3K8lRPAbf6iYbroqhJN',
        ceEnv: 'prd0-aws-euw1',
        ceUrl: 'https://api.cloud-elements.co.uk',
    };

    const apacProductionDefaults = {
        ...defaults,
        auth0Domain: 'cloudelements.au.auth0.com',
        auth0ClientId: 'tu1vpb0ZJCDtJ6G84CFQtszl3po98kni',
        ceEnv: 'apac0',
        ceUrl: 'https://api.apac.cloudelements.io',
    };

    const eunpProductionDefaults = {
        ...defaults,
        imageHost: ['images.cloudelements.io', 'images.es-eunorth-prod-0.aws-eunp.cloudelements.app'],
        auth0Domain: 'cloudelements-north.eu.auth0.com',
        auth0ClientId: 'U77GAZcmsBwDm1QM6vecfunXWjomOcAo',
        ceEnv: 'es-eunorth-prod-0',
        ceUrl: 'https://api.es-eunorth-prod-0.aws-eunp.cloudelements.app',
    };

    const usepProductionDefaults = {
        ...defaults,
        imageHost: ['images.cloudelements.io', 'images.es-useast-prod-0.aws-usep.cloudelements.app'],
        auth0Domain: 'cloudelements-east.us.auth0.com',
        auth0ClientId: '9CFjTBjNEUd4CVR3s6eMsCYbISDWyTch',
        ceEnv: 'es-useast-prod-0',
        ceUrl: 'https://api.es-useast-prod-0.aws-usep.cloudelements.app',
    };

    const jpepProductionDefaults = {
        ...defaults,
        imageHost: ['images.cloudelements.io', 'images.es-jpeast-prod-0.aws-jpep.cloudelements.app'],
        auth0Domain: 'cloudelements-east.jp.auth0.com',
        auth0ClientId: 'aQzrdwi6AVn5TT3eDMrXGtI7kIJb2s9g',
        ceEnv: 'es-jpeast-prod-0',
        ceUrl: 'https://api.es-jpeast-prod-0.aws-jpep.cloudelements.app',
    };

    const auepProductionDefaults = {
        ...defaults,
        auth0Domain: 'cloudelements-aueast.au.auth0.com',
        auth0ClientId: '8ImxSVvgl7HviEXbgIC9u7hlmE1F9KMD',
        ceEnv: 'es-aueast-prod-0',
        ceUrl: 'https://api.es-aueast-prod-0.aws-auep.cloudelements.app',
    };

    const apsepProductionDefaults = {
        ...defaults,
        auth0Domain: 'cloudelements-apacsoutheast.jp.auth0.com',
        auth0ClientId: 'Na3ADrbTWdDmC6VtiI6DlDz02uOzegCN',
        ceEnv: 'es-apacsoutheast-prod-0',
        ceUrl: 'https://api.es-apacsoutheast-prod-0.aws-apsep.cloudelements.app',
    };

    const stagingDefaults = {
        ...defaults,
        imageHost: ['images.cloudelements.io', 'images.staging.cloudelements.app'],
        LDClientId: '592ef8c4c38c010a45847f5b',
        auth0Domain: 'cloudelements-staging.auth0.com',
        auth0ClientId: 'rz7G5j6CU2Wz4afHzDCXvZ5pSfFmxz1V',
        ceEnv: 'stg0-aws-usw2',
        ceUrl: 'https://staging.cloud-elements.com',
    };

    const uswaDefaults = {
        ...defaults,
        imageHost: ['images.cloudelements.io', 'images.es-uswest-alpha-0.aws-uswa.cloudelements.app'],
        LDClientId: '592ef8c4c38c010a45847f5b',
        auth0Domain: 'es-uswest-alpha-0.us.auth0.com',
        auth0ClientId: 'ilvTVjkdnOQTQHCDKbydyatlXUisNnfe',
        ceEnv: 'es-uswest-alpha-0',
        ceUrl: 'https://api.es-uswest-alpha-0.aws-uswa.cloudelements.app',
    };

    const stage0Defaults = {
        ...defaults,
        imageHost: ['images.cloudelements.io', 'images.staging.cloudelements.app'],
        LDClientId: '592ef8c4c38c010a45847f5b',
        auth0Domain: 'cloudelements-staging.auth0.com',
        auth0ClientId: 'rz7G5j6CU2Wz4afHzDCXvZ5pSfFmxz1V',
        ceEnv: 'stage0',
        ceUrl: 'https://api.staging.us.cloudelements.io',
    };

    const euwsStagingDefaults = {
        ...defaults,
        imageHost: ['images.cloudelements.io', 'images.es-euwest-stage-0.aws-euws.cloudelements.app'],
        LDClientId: '592ef8c4c38c010a45847f5b',
        auth0Domain: 'es-euwest-stage-0.eu.auth0.com',
        auth0ClientId: 'cXvjn0sbow1J3cNxNY1dmei0tdNpNHjn',
        ceEnv: 'es-euwest-stage-0',
        ceUrl: 'https://api.es-euwest-stage-0.aws-euws.cloudelements.app',
    };

    const snapshotDefaults = {
        ...defaults,
        imageHost: ['images.cloudelements.io', 'images.snap0.snapshot.cloudelements.app'],
        LDClientId: '59404c12f532ed0c3dfe9b21',
        auth0Domain: 'cloudelements-snapshot.auth0.com',
        auth0ClientId: 'kGAvUmsGfs2PWkOVbL3yGoh0KDoGTu9x',
        ceEnv: 'snp0-aws-usw2',
        ceUrl: 'https://api.snapshot.us.cloudelements.io',
    };

    const snap0Defaults = {
        ...defaults,
        imageHost: ['images.cloudelements.io', 'images.snap0.snapshot.cloudelements.app'],
        LDClientId: '59404c12f532ed0c3dfe9b21',
        auth0Domain: 'cloudelements-snapshot.auth0.com',
        auth0ClientId: 'kGAvUmsGfs2PWkOVbL3yGoh0KDoGTu9x',
        ceEnv: 'snap0',
        ceUrl: 'https://api.snapshot.us.cloudelements.io',
    };

    console.log(`Looking up soba environment config for SOBA_ENV: ${process.SOBA_ENV}`);
    switch (process.SOBA_ENV) {
        case 'production':
            return {
                ...usProductionDefaults,
                env: 'production',
                url: 'https://api.cloud-elements.com',
                host: 'api.cloud-elements.com',
                loginNotification: false,
                loadDataDog: true,
                useIdentity: true,
                shouldShowSSO: true,
            };
        case 'production-uk':
            return {
                ...euProductionDefaults,
                env: 'production-uk',
                url: 'https://api.cloud-elements.co.uk',
                host: 'api.cloud-elements.co.uk',
                loginNotification: false,
                loadDataDog: true,
                useIdentity: true,
                shouldShowSSO: true,
            };
        case 'apac0':
            return {
                ...apacProductionDefaults,
                env: 'apac0',
                url: 'https://api.apac.cloudelements.io',
                host: 'api.apac.cloudelements.io',
                loginNotification: false,
                useIdentity: true,
                loadDataDog: true,
                shouldShowSSO: true,
            };
        case 'es-eunorth-prod-0':
            return {
                ...eunpProductionDefaults,
                env: 'es-eunorth-prod-0',
                url: 'https://api.es-eunorth-prod-0.aws-eunp.cloudelements.app',
                host: 'api.es-eunorth-prod-0.aws-eunp.cloudelements.app',
                loginNotification: false,
                useIdentity: true,
                loadDataDog: true,
            };
        case 'es-useast-prod-0':
            return {
                ...usepProductionDefaults,
                env: 'es-useast-prod-0',
                url: 'https://api.es-useast-prod-0.aws-usep.cloudelements.app',
                host: 'api.es-useast-prod-0.aws-usep.cloudelements.app',
                loginNotification: false,
                useIdentity: true,
                loadDataDog: true,
            };
        case 'es-jpeast-prod-0':
            return {
                ...jpepProductionDefaults,
                env: 'es-jpeast-prod-0',
                url: 'https://api.es-jpeast-prod-0.aws-jpep.cloudelements.app',
                host: 'api.es-jpeast-prod-0.aws-jpep.cloudelements.app',
                loginNotification: false,
                useIdentity: true,
                loadDataDog: true,
            };
        case 'es-aueast-prod-0':
            return {
                ...auepProductionDefaults,
                env: 'es-aueast-prod-0',
                url: 'https://api.es-aueast-prod-0.aws-auep.cloudelements.app',
                host: 'api.es-aueast-prod-0.aws-auep.cloudelements.app',
                loginNotification: false,
                useIdentity: true,
                loadDataDog: true,
            };
        case 'es-apacsoutheast-prod-0':
            return {
                ...apsepProductionDefaults,
                env: 'es-apacsoutheast-prod-0',
                url: 'https://api.es-apacsoutheast-prod-0.aws-apsep.cloudelements.app',
                host: 'aapi.es-apacsoutheast-prod-0.aws-apsep.cloudelements.app',
                loginNotification: false,
                useIdentity: true,
                loadDataDog: true,
            };
        case 'staging':
            return {
                ...stagingDefaults,
                env: 'staging',
                url: 'https://staging.cloud-elements.com',
                host: 'staging.cloud-elements.com',
                loginNotification: false,
                loadDataDog: true,
                useIdentity: true,
                shouldShowSSO: true,
            };
        case 'stage0':
            return {
                ...stage0Defaults,
                env: 'stage0',
                url: 'https://api.staging.us.cloudelements.io',
                host: 'api.staging.us.cloudelements.io',
                loginNotification: false,
                loadDataDog: true,
                useIdentity: true,
                shouldShowSSO: true,
            };
        case 'es-euwest-stage-0':
            return {
                ...euwsStagingDefaults,
                env: 'es-euwest-stage-0',
                url: 'https://api.es-euwest-stage-0.aws-euws.cloudelements.app',
                host: 'api.es-euwest-stage-0.aws-euws.cloudelements.app',
                loginNotification: false,
                useIdentity: true,
                loadDataDog: true,
            };
        case 'es-uswest-alpha-0':
            return {
                ...uswaDefaults,
                env: 'es-uswest-alpha-0',
                url: 'https://api.es-uswest-alpha-0.aws-uswa.cloudelements.app',
                host: 'api.es-uswest-alpha-0.aws-uswa.cloudelements.app',
                loginNotification: false,
                loadDataDog: true,
                useIdentity: true,
            };
        case 'localhost':
            return {
                ...defaults,
                env: 'localhost',
                url: `http://localhost:${process.SOBA_PORT || 8080}`,
                ceUrl: 'https://dev.cloud-elements.com', // NEEDED for Auth0
                host: `localhost:${process.SOBA_PORT || 8080}`,
                auth0Domain: 'cloudelements-dev.auth0.com',
                auth0ClientId: '1lF020xIzCp6cYGP77cHUJm78ETRvWSh',
                LDClientId: '59404c1bc7d6d80bedd3ff41',
                shouldShowSSO: true,
            };
        case 'ibm-bluemix':
            return {
                ...skeletorEnv,
                awsUrl: process.AWS_URL,
                production,
                env: 'ibm-bluemix',
                url: 'https://ibm.cloud-elements.com',
                host: 'ibm.cloud-elements.com',
                staticUrl: '/assets',
                LDClientId: '',
                intercomId: '',
                imageHost: 'my-ibm.cloud-elements.com',
                elementImages: process.Element_Image_List,
                approvedOAuthOrigins: [],
                approvedOauthResponders,
                zendeskWidgetHost: '',
            };
        case 'sap-snapshot':
            // connects to CE US Snapshot
            return {
                ...snapshotDefaults,
                env: 'sap-snapshot',
                url: 'https://api.openconnectors.ext.int.sap.hana.ondemand.com',
                host: 'api.openconnectors.ext.int.sap.hana.ondemand.com',
                ui: 'ui5',
            };
        case 'sap-ext-trial':
            // connects to CE US Staging
            return {
                ...stagingDefaults,
                env: 'sap-ext-trial',
                url: 'https://api.openconnectors.ext.hanatrial.ondemand.com',
                host: 'api.openconnectors.ext.hanatrial.ondemand.com',
                ui: 'ui5',
            };
        case 'sap-us2-ext':
            // connects to CE US Production
            return {
                ...usProductionDefaults,
                env: 'sap-us2-ext',
                url: 'https://api.openconnectors.us2.ext.hana.ondemand.com',
                host: 'api.openconnectors.us2.ext.hana.ondemand.com',
                approvedOAuthOrigins: [],
                ui: 'ui5',
            };
        case 'sap-us4-ext':
            // connects to CE US Production
            return {
                ...usProductionDefaults,
                env: 'sap-us4-ext',
                url: 'https://api.openconnectors.us4.ext.hana.ondemand.com',
                host: 'api.openconnectors.us4.ext.hana.ondemand.com',
                approvedOAuthOrigins: [],
                ui: 'ui5',
            };
        case 'sap-us10-ext':
            // connects to CE US Production
            return {
                ...usProductionDefaults,
                env: 'sap-us10-ext',
                url: 'https://api.openconnectors.us10.ext.hana.ondemand.com',
                host: 'api.openconnectors.us10.ext.hana.ondemand.com',
                approvedOAuthOrigins: [],
                ui: 'ui5',
            };
        case 'sap-us20-ext':
            // connects to CE US Production
            return {
                ...usProductionDefaults,
                env: 'sap-us20-ext',
                url: 'https://api.openconnectors.us20.ext.hana.ondemand.com',
                host: 'api.openconnectors.us20.ext.hana.ondemand.com',
                approvedOAuthOrigins: [],
                ui: 'ui5',
            };
        case 'sap-us21-ext':
            // connects to CE US Production
            return {
                ...usProductionDefaults,
                env: 'sap-us21-ext',
                url: 'https://api.openconnectors.us21.ext.hana.ondemand.com',
                host: 'api.openconnectors.us21.ext.hana.ondemand.com',
                approvedOAuthOrigins: [],
                ui: 'ui5',
            };
        case 'sap-us30-ext':
            // connects to CE US Production
            return {
                ...usProductionDefaults,
                env: 'sap-us30-ext',
                url: 'https://api.openconnectors.us30.ext.hana.ondemand.com',
                host: 'api.openconnectors.us30.ext.hana.ondemand.com',
                approvedOAuthOrigins: [],
                ui: 'ui5',
                showWidgetDashboard: true
            };
        case 'sap-ca10-ext':
            // connects to CE US Production
            return {
                ...usProductionDefaults,
                env: 'sap-ca10-ext',
                url: 'https://api.openconnectors.ca10.ext.hana.ondemand.com',
                host: 'api.openconnectors.ca10.ext.hana.ondemand.com',
                approvedOAuthOrigins: [],
                ui: 'ui5',
            };
        case 'sap-br10-ext':
            // connects to CE US Production
            return {
                ...usProductionDefaults,
                env: 'sap-br10-ext',
                url: 'https://api.openconnectors.br10.ext.hana.ondemand.com',
                host: 'api.openconnectors.br10.ext.hana.ondemand.com',
                approvedOAuthOrigins: [],
                ui: 'ui5',
            };
        case 'sap-eu-ext':
            // connects to CE UK Production
            return {
                ...euProductionDefaults,
                env: 'sap-eu-ext',
                url: 'https://api.openconnectors.ext.hana.ondemand.com',
                host: 'api.openconnectors.ext.hana.ondemand.com',
                ui: 'ui5',
            };
        case 'sap-eu2-ext':
            // connects to CE UK Production
            return {
                ...euProductionDefaults,
                env: 'sap-eu2-ext',
                url: 'https://api.openconnectors.eu2.ext.hana.ondemand.com',
                host: 'api.openconnectors.eu2.ext.hana.ondemand.com',
                ui: 'ui5',
            };
        case 'sap-eu3-ext':
            // connects to CE UK Production
            return {
                ...euProductionDefaults,
                env: 'sap-eu3-ext',
                url: 'https://api.openconnectors.eu3.ext.hana.ondemand.com',
                host: 'api.openconnectors.eu3.ext.hana.ondemand.com',
                ui: 'ui5',
            };
        case 'sap-eu10-ext':
            // connects to CE UK Production
            return {
                ...euProductionDefaults,
                env: 'sap-eu10-ext',
                url: 'https://api.openconnectors.eu10.ext.hana.ondemand.com',
                host: 'api.openconnectors.eu10.ext.hana.ondemand.com',
                ui: 'ui5',
            };
        case 'sap-eu11-ext':
            // connects to CE UK Production
            return {
                ...euProductionDefaults,
                env: 'sap-eu11-ext',
                url: 'https://api.openconnectors.eu11.ext.hana.ondemand.com',
                host: 'api.openconnectors.eu11.ext.hana.ondemand.com',
                ui: 'ui5',
            };
        case 'sap-eu12-ext':
            // connects to CE UK Production
            return {
                ...euProductionDefaults,
                // changelog,
                // release,
                env: 'sap-eu12-ext',
                url: 'https://api.openconnectors.eu12.ext.hana.ondemand.com',
                host: 'api.openconnectors.eu12.ext.hana.ondemand.com',
                ui: 'ui5',
            };
        case 'sap-eu20-ext':
            // connects to CE UK Production
            return {
                ...euProductionDefaults,
                env: 'sap-eu20-ext',
                url: 'https://api.openconnectors.eu20.ext.hana.ondemand.com',
                host: 'api.openconnectors.eu20.ext.hana.ondemand.com',
                ui: 'ui5',
            };
        case 'sap-eu30-ext':
            // connects to CE UK Production
            return {
                ...euProductionDefaults,
                env: 'sap-eu30-ext',
                url: 'https://api.openconnectors.eu30.ext.hana.ondemand.com',
                host: 'api.openconnectors.eu30.ext.hana.ondemand.com',
                ui: 'ui5',
            };
        case 'sap-jp20-ext':
            // connects to CE UK Production
            return {
                ...euProductionDefaults,
                env: 'sap-jp20-ext',
                url: 'https://api.openconnectors.jp20.ext.hana.ondemand.com',
                host: 'api.openconnectors.jp20.ext.hana.ondemand.com',
                ui: 'ui5',
            };
        case 'sap-jp10-ext':
            // connects to CE UK Production
            return {
                ...euProductionDefaults,
                env: 'sap-jp10-ext',
                url: 'https://api.openconnectors.jp10.ext.hana.ondemand.com',
                host: 'api.openconnectors.jp10.ext.hana.ondemand.com',
                ui: 'ui5',
            };
        case 'sap-ap10-ext':
            // connects to CE UK Production
            return {
                ...euProductionDefaults,
                env: 'sap-ap10-ext',
                url: 'https://api.openconnectors.ap10.ext.hana.ondemand.com',
                host: 'api.openconnectors.ap10.ext.hana.ondemand.com',
                ui: 'ui5',
            };
        case 'sap-ap10s-ext':
            // connects to CE APAC Production
            return {
                ...apacProductionDefaults,
                env: 'sap-ap10s-ext',
                url: 'https://api.openconnectors.ap10s.ext.hana.ondemand.com',
                host: 'api.openconnectors.ap10s.ext.hana.ondemand.com',
                ui: 'ui5',
            };
        case 'sap-ap11-ext':
            // connects to CE UK Production
            return {
                ...euProductionDefaults,
                env: 'sap-ap11-ext',
                url: 'https://api.openconnectors.ap11.ext.hana.ondemand.com',
                host: 'api.openconnectors.ap11.ext.hana.ondemand.com',
                ui: 'ui5',
            };
        case 'sap-ap12-ext':
            // connects to CE APAC Production
            return {
                ...apacProductionDefaults,
                env: 'sap-ap12-ext',
                url: 'https://api.openconnectors.ap12.ext.hana.ondemand.com',
                host: 'api.openconnectors.ap12.ext.hana.ondemand.com',
                ui: 'ui5',
            };
        case 'sap-ap20-ext':
            // connects to CE APAC Production
            return {
                ...apacProductionDefaults,
                env: 'sap-ap20-ext',
                url: 'https://api.openconnectors.ap20.ext.hana.ondemand.com',
                host: 'api.openconnectors.ap20.ext.hana.ondemand.com',
                ui: 'ui5',
            };
        case 'sap-ap21-ext':
            // connects to CE UK Production
            return {
                ...euProductionDefaults,
                env: 'sap-ap21-ext',
                url: 'https://api.openconnectors.ap21.ext.hana.ondemand.com',
                host: 'api.openconnectors.ap21.ext.hana.ondemand.com',
                ui: 'ui5',
            };
        case 'sap-in30-ext':
            // connects to CE APAC Production
            return {
                ...apacProductionDefaults,
                env: 'sap-in30-ext',
                url: 'https://api.openconnectors.in30.ext.hana.ondemand.com',
                host: 'api.openconnectors.in30.ext.hana.ondemand.com',
                ui: 'ui5',
            };
        case 'sap-trial-ap21-ext':
            // connects to CE US Staging
            return {
                ...stagingDefaults,
                env: 'sap-trial-ap21-ext',
                url: 'https://api.openconnectors.trial.ap21.ext.hana.ondemand.com',
                host: 'api.openconnectors.trial.ap21.ext.hana.ondemand.com',
                ui: 'ui5',
            };
        case 'sap-trial-eu10-ext':
            // connects to CE US Staging
            return {
                ...stagingDefaults,
                env: 'sap-trial-eu10-ext',
                url: 'https://api.openconnectors.trial.eu10.ext.hana.ondemand.com',
                host: 'api.openconnectors.trial.eu10.ext.hana.ondemand.com',
                ui: 'ui5',
            };
        case 'sap-trial-eu20-ext':
            // connects to CE US Staging
            return {
                ...stagingDefaults,
                env: 'sap-trial-eu20-ext',
                url: 'https://api.openconnectors.trial.eu20.ext.hana.ondemand.com',
                host: 'api.openconnectors.trial.eu20.ext.hana.ondemand.com',
                ui: 'ui5',
            };
        case 'sap-trial-us30-ext':
            // connects to CE US Staging
            return {
                ...stagingDefaults,
                env: 'sap-trial-us30-ext',
                url: 'https://api.openconnectors.trial.us30.ext.hana.ondemand.com',
                host: 'api.openconnectors.trial.us30.ext.hana.ondemand.com',
                ui: 'ui5',
            };
        case 'sap-trial-us10-ext':
            // connects to CE US Staging
            return {
                ...stagingDefaults,
                env: 'sap-trial-us10-ext',
                url: 'https://api.openconnectors.trial.us10.ext.hana.ondemand.com',
                host: 'api.openconnectors.trial.us10.ext.hana.ondemand.com',
                ui: 'ui5',
            };
        case 'sugar-us-staging':
            // connects to CE US Staging
            return {
                ...stagingDefaults,
                env: 'sugar-us-staging',
                brandedLogin: {
                    logo: 'logos/sugar.svg',
                    backgroundCss: {
                        'background-color': '#f8f8f8',
                        'background-image': 'url(/assets/img/backgrounds/sugar.svg)',
                        'background-repeat': 'no-repeat',
                        'background-size': '500px auto',
                        'background-position': 'top right',
                    },
                    showSignup: false,
                    showOAuth: false,
                    privacyUrl: 'https://www.sugarcrm.com/legal/privacy-policy/',
                },
                url: 'https://api-us-staging.integrate.sugarapps.com',
                host: 'api-us-staging.integrate.sugarapps.com',
                loadDataDog: true,
            };
        case 'sugar-us-production':
            // connects to CE US Production
            return {
                ...usProductionDefaults,
                env: 'sugar-us-production',
                brandedLogin: {
                    logo: 'logos/sugar.svg',
                    backgroundCss: {
                        'background-color': '#f8f8f8',
                        'background-image': 'url(/assets/img/backgrounds/sugar.svg)',
                        'background-repeat': 'no-repeat',
                        'background-size': '500px auto',
                        'background-position': 'top right',
                    },
                    showSignup: false,
                    showOAuth: false,
                    privacyUrl: 'https://www.sugarcrm.com/legal/privacy-policy/',
                },
                url: 'https://api-us.integrate.sugarapps.com',
                host: 'api-us.integrate.sugarapps.com',
                loadDataDog: true,
            };
        case 'sugar-ie-production':
            // connects to CE EU Production
            return {
                ...euProductionDefaults,
                env: 'sugar-ie-production',
                brandedLogin: {
                    logo: 'logos/sugar.svg',
                    backgroundCss: {
                        'background-color': '#f8f8f8',
                        'background-image': 'url(/assets/img/backgrounds/sugar.svg)',
                        'background-repeat': 'no-repeat',
                        'background-size': '500px auto',
                        'background-position': 'top right',
                    },
                    showSignup: false,
                    showOAuth: false,
                    privacyUrl: 'https://www.sugarcrm.com/legal/privacy-policy/',
                },
                url: 'https://api-ie.integrate.sugarapps.com',
                host: 'api-ie.integrate.sugarapps.com',
                approvedOAuthOrigins,
                loadDataDog: true,
            };
        case 'sugar-au-production':
            // connects to CE APAC Production
            return {
                ...apacProductionDefaults,
                env: 'sugar-au-production',
                brandedLogin: {
                    logo: 'logos/sugar.svg',
                    backgroundCss: {
                        'background-color': '#f8f8f8',
                        'background-image': 'url(/assets/img/backgrounds/sugar.svg)',
                        'background-repeat': 'no-repeat',
                        'background-size': '500px auto',
                        'background-position': 'top right',
                    },
                    showSignup: false,
                    showOAuth: false,
                    privacyUrl: 'https://www.sugarcrm.com/legal/privacy-policy/',
                },
                url: 'https://api-au.integrate.sugarapps.com',
                host: 'api-au.integrate.sugarapps.com',
                approvedOAuthOrigins,
                loadDataDog: true,
            };
        case 'test':
            // connects to CE US Snapshot
            return {
                ...snapshotDefaults,
                env: 'test',
                url: 'https://api.snapshot.us.cloudelements.io',
                host: 'api.snapshot.us.cloudelements.io',
                useIdentity: true,
            };
        case 'snap0-test':
            // connects to CE US Snap0
            return {
                ...snap0Defaults,
                env: 'test',
                url: 'https://api.snapshot.us.cloudelements.io',
                host: 'api.snapshot.us.cloudelements.io',
                useIdentity: true,
                shouldShowSSO: true,
            };
        case 'staging-test':
            // connects to CE US Staging
            return {
                ...stagingDefaults,
                env: 'test',
                url: 'https://staging.cloud-elements.com',
                host: 'staging.cloud-elements.com',
                useIdentity: true,
                shouldShowSSO: true,
            };
        case 'stage0-test':
            // connects to CE US Stage0
            return {
                ...stage0Defaults,
                env: 'test',
                url: 'https://api.staging.us.cloudelements.io',
                host: 'api.staging.us.cloudelements.io',
                useIdentity: true,
                shouldShowSSO: true,
            };
        case 'es-euwest-stage-0-test':
            // connects to CE EUWS Staging
            return {
                ...euwsStagingDefaults,
                env: 'test',
                url: 'https://api.es-euwest-stage-0.aws-euws.cloudelements.app',
                host: 'api.es-euwest-stage-0.aws-euws.cloudelements.app',
                useIdentity: true,
            };
        case 'es-uswest-alpha-0-test':
            // connects to UiPath US es-uswest-alpha-0
            return {
                ...uswaDefaults,
                env: 'test',
                url: 'https://api.es-uswest-alpha-0.aws-uswa.cloudelements.app',
                host: 'api.es-uswest-alpha-0.aws-uswa.cloudelements.app',
                useIdentity: true,
            };
        case 'production-test':
            // connects to CE US Production
            return {
                ...usProductionDefaults,
                env: 'test',
                url: 'https://api.cloud-elements.com',
                host: 'api.cloud-elements.com',
                useIdentity: true,
                shouldShowSSO: true,
            };
        case 'apac0-test':
            // connects to CE APAC Production
            return {
                ...apacProductionDefaults,
                env: 'test',
                url: 'https://api.apac.cloudelements.io',
                host: 'api.apac.cloudelements.io',
                useIdentity: true,
            };
        case 'es-eunorth-prod-0-test':
            // connects to CE EUNP Production
            return {
                ...eunpProductionDefaults,
                env: 'test',
                url: 'https://api.es-eunorth-prod-0.aws-eunp.cloudelements.app',
                host: 'api.es-eunorth-prod-0.aws-eunp.cloudelements.app',
                useIdentity: true,
            };
        case 'es-useast-prod-0-test':
            // connects to CE USEAST Production
            return {
                ...useastProductionDefaults,
                env: 'test',
                url: 'https://api.es-useast-prod-0.aws-usep.cloudelements.app',
                host: 'api.es-useast-prod-0.aws-usep.cloudelements.app',
                useIdentity: true,
            };
        case 'es-jpeast-prod-0-test':
            // connects to CE JPEAST Production
            return {
                ...jpeastProductionDefaults,
                env: 'test',
                url: 'https://api.es-jpeast-prod-0.aws-jpep.cloudelements.app',
                host: 'api.es-jpeast-prod-0.aws-jpep.cloudelements.app',
                useIdentity: true,
            };
        case 'es-aueast-prod-0-test':
            // connects to CE AUEAST Production
            return {
                ...aueastProductionDefaults,
                env: 'test',
                url: 'https://api.es-aueast-prod-0.aws-auep.cloudelements.app',
                host: 'api.es-aueast-prod-0.aws-auep.cloudelements.app',
                useIdentity: true,
            };
        case 'es-apacsoutheast-prod-0-test':
            // connects to CE APSEP Production
            return {
                ...apsepProductionDefaults,
                env: 'test',
                url: 'https://api.es-apacsoutheast-prod-0.aws-apsep.cloudelements.app',
                host: 'api.es-apacsoutheast-prod-0.aws-apsep.cloudelements.app',
                useIdentity: true,
            };
        case 'snap0':
            /** make this default after snp0 has been decommed */
            return {
                ...snap0Defaults,
                env: 'snap0',
                url: 'https://api.snapshot.us.cloudelements.io',
                host: 'api.snapshot.us.cloudelements.io',
                loadDataDog: true,
                useIdentity: false, // snap0 is now snapshot, so this will likely die
                shouldShowSSO: true,
            };
        case 'snapshot':
        default:
            return {
                ...snapshotDefaults,
                env: 'snapshot',
                url: 'https://api.snapshot.us.cloudelements.io',
                host: 'api.snapshot.us.cloudelements.io',
                staticUrl: process.BASE_PATH ? `${process.BASE_PATH}/assets` : '/assets',
                loadDataDog: true,
                useIdentity: true,
                shouldShowSSO: true,
            };
    }
};

/**
 * Builds the configuration object based on the NODE_ENV
 * environment variable. Injected at build time
 * (changes will therefore require a webpack restart)
 * @return {Object} the configuration object
 */
const build = () => {
    const production = process.NODE_ENV === 'production';
    const skeletorEnv = buildSkeletorEnvConfig();
    return buildSobaEnvConfig(skeletorEnv, production);
};
let envObject = build();
if (process.BASE_PATH) {
    envObject.basePath = process.BASE_PATH;
}
Object.keys(globalDefaults).forEach((prop) => {
    if (typeof envObject[prop] === 'undefined') {
        envObject[prop] = globalDefaults[prop];
    }
});
if (envObject.title) {
    document.title = envObject.title;
}
if (environments && process.ENVIRONMENT_TYPE) {
    envObject.targetEnvironments = getTargetEnvironmentListForType();
}
sessionStorage.setItem('skeletor-envs', JSON.stringify(envObject));