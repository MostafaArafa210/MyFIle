let process = {
    "Element_Image_List": "abbyy,actessentials,actessentialsoauth,acton,actpremium,actpremiumcrm,acuityscheduling,adobe-esign,adplifion,adpworkforcenow,allbound,amazon-aws,amazonmarketplace,amazons3,autopilot,autotaskcrm,autotaskfinance,autotaskhelpdesk,awsredshift,axxerion,azureblob,bamboohr,base,bazaarvoice,bigcommerce,bigquery,box,brandfolder,brighttalk,bullhorn,caagilecentral,campaignmonitor,chargebee,chargebeev2,chargify,cherwell,ciscospark,closeio,clover,concur,concurv4,connectwisecrm,connectwisecrmrest,connectwisehd,constantcontact,coupa,desk,docushareflex,docusign,dropbox,dropboxbusiness,dropboxbusinessv2,dropboxv2,dynamicscrmadfs,dynamicscrmrest,dynamicshr,dynamicsnavisionerp,ecwid,egnyte,eloqua,epages,etsy,eventmobiv1,evernote,expensify,facebook,facebookleadads,facebooksocial,fieldawarev2,fieldlocate,files,flickr,flickr2,fortnox,freshbooks,freshbooksv2,freshdesk,freshdeskv2,freshservice,github,globalmeet,gmail,gooddata,googleadwords,googlecalendar,googlecalender,googlecloudstorage,googledrive,googleoauth,googlesheets,googlesheetsv4,googlesuite,gotowebinar,greatplains,greenhouse,helpscout,hireright,hootsuite,hubspot,hubspotcrm,icontact,infobip,infor,infusionsoft,infusionsoftcrm,infusionsoftecommerce,infusionsoftmarketing,infusionsoftrest,insightly,instagram,intacct,intercom,jira,jiraonprem,kissmetrics,launchbI,linkedin,lithiumlsw,magento,magentosoapv19,magentov20,mailchimpv3,mailjet,mailjetmarketing,marketo,maximizer,messagebus,microsoft-onedrive-sharepoint-graph,microsoftgraph,mixpanel,mongodb,ms-sqlserver,msbusinesscentral,myob,mysql,namely,netsuitecrm,netsuitecrmv2,netsuitecrmv3,netsuiteerp,netsuiteerpv2,netsuiteerpv3,netsuitefinance,netsuitefinancev2,netsuitefinancev3,netsuitehc,netsuitehcv2,netsuitehcv3,nimsoft,office365,onedrive,onedrivebusiness,onedrivev2,onenote,oracledb,oraclehcmcloud,oraclesalescloud,outlookemail,pardot,paypalv2,pipedrive,plaid,posable,postgresql,quickbase,quickbooks,quickbooksonprem,readytalk,readytalkilluminate,recurly,revel,sage200,sage50us,sageaccounting,sagecrm,sagelive,sageone,sageoneuk,sageoneus,sailthru,salesforcebylaunchbi,salesforcemarketingcloud,salesloft,sap,sapanywhere,sapariba,sapbobylaunchbi,sapborestbylaunchbi,sapbusinessone,sapc4ccrm,sapc4chd,sendgrid,sendoso,servicecloud,servicemax,servicenow,servicenowoauth,sfdc,sfdcdocuments,sfdclibraries,sfdcservicecloud,sfdcv2,sftp,sharefile,sharepoint,shopify,slack,smartrecruiters,snapforce,snowflake,sqlserver,square,stormpath,strava,stripe,successfactors,sugarcrmv2,sugarenterprise,sugarprofessional,sugarsell,sugarserve,syncplicity,tableaubylaunchbi,taleobusiness,tangocard,taxify,terminus,tipalti,twilio,twiliov2,twitter,typeform,uipath-atlassian-jira,uipath-servicenow-servicenow,ultimateultipro,vcloud,volusion,vsts,weebly,woocommerce,woocommercerest,wrike,wufoo,xero,xerov2,zendesk,zendesksell,zohocrm,zohocrmv2,zuora,zuorav2",
    "NODE_ENV": "production"
};
/* eslint-disable no-unused-vars */
// Cloud Elements Environments
const CE_PRODUCTION_UK = {
    skeletorEndpoint: 'https://my.cloudelements.co.uk',
    backendEndpoint: 'https://api.cloud-elements.co.uk',
    environmentName: 'production-uk',
    displayName: 'Production UK',
};

const CE_SNAPSHOT_US = {
    skeletorEndpoint: 'https://my-snapshot.cloudelements.io',
    backendEndpoint: 'https://api.snapshot.us.cloudelements.io',
    environmentName: 'snapshot',
    displayName: 'Snapshot',
};

const CE_SNAP0_US = {
    skeletorEndpoint: 'https://my.snap0.cloudelements.io',
    backendEndpoint: 'https://api.snapshot.us.cloudelements.io',
    environmentName: 'snap0',
    displayName: 'SNAP0',
};

const CE_STAGING_US = {
    skeletorEndpoint: 'https://my-staging.cloudelements.io',
    backendEndpoint: 'https://staging.cloud-elements.com',
    environmentName: 'staging',
    displayName: 'Staging',
};

const CE_STAGE0_US = {
    skeletorEndpoint: 'https://my.stage0.cloudelements.io',
    backendEndpoint: 'https://api.staging.us.cloudelements.io',
    environmentName: 'stage0',
    displayName: 'STAGE0',
};

const CE_EUWS_EU = {
    skeletorEndpoint: 'https://my.es-euwest-stage-0.aws-euws.cloudelements.app',
    backendEndpoint: 'https://api.es-euwest-stage-0.aws-euws.cloudelements.app',
    environmentName: 'es-euwest-stage-0',
    displayName: 'EU West Stage',
};

const CE_USWA_US = {
    skeletorEndpoint: 'https://my.es-uswest-alpha-0.aws-uswa.cloudelements.app',
    backendEndpoint: 'https://api.es-uswest-alpha-0.aws-uswa.cloudelements.app',
    environmentName: 'es-uswest-alpha-0',
    displayName: 'US WEST ALPHA',
};

const CE_PRODUCTION_AP = {
    skeletorEndpoint: 'https://my.apac.cloudelements.io',
    backendEndpoint: 'https://api.apac.cloudelements.io',
    environmentName: 'apac0',
    displayName: 'APAC',
};

const CE_EUNP_EU = {
    skeletorEndpoint: 'https://my.es-eunorth-prod-0.aws-eunp.cloudelements.app',
    backendEndpoint: 'https://api.es-eunorth-prod-0.aws-eunp.cloudelements.app',
    environmentName: 'es-eunorth-prod-0',
    displayName: 'EU North Production',
};

const CE_USEP_US = {
    skeletorEndpoint: 'https://my.es-useast-prod-0.aws-usep.cloudelements.app',
    backendEndpoint: 'https://api.es-useast-prod-0.aws-usep.cloudelements.app',
    environmentName: 'es-useast-prod-0',
    displayName: 'US EAST Production',
};

const CE_JPEP_JP = {
    skeletorEndpoint: 'https://my.es-jpeast-prod-0.aws-jpep.cloudelements.app',
    backendEndpoint: 'https://api.es-jpeast-prod-0.aws-jpep.cloudelements.app',
    environmentName: 'es-jpeast-prod-0',
    displayName: 'JAPAN EAST Production',
};

const CE_AUEP_AU = {
    skeletorEndpoint: 'https://my.es-aueast-prod-0.aws-auep.cloudelements.app',
    backendEndpoint: 'https://api.es-aueast-prod-0.aws-auep.cloudelements.app',
    environmentName: 'es-aueast-prod-0',
    displayName: 'AUSTRALIA EAST Production',
};

const CE_APSEP_AP = {
    skeletorEndpoint: 'https://my.es-apacsoutheast-prod-0.aws-apsep.cloudelements.app',
    backendEndpoint: 'https://api.es-apacsoutheast-prod-0.aws-apsep.cloudelements.app',
    environmentName: 'es-apacsoutheast-prod-0',
    displayName: 'SINGAPORE EAST Production',
};

const CE_PRODUCTION_US = {
    skeletorEndpoint: 'https://my.cloudelements.io',
    backendEndpoint: 'https://api.cloud-elements.com',
    environmentName: 'production',
    displayName: 'Production US',
};

const LOCAL = {
    skeletorEndpoint: 'http://localhost:8111',
    backendEndpoint: 'http://localhost:8080',
    environmentName: 'localhost',
    displayName: 'Localhost',
};

const LOCAL_DEV = {
    skeletorEndpoint: 'https://my-localhost.cloudelements.io',
    backendEndpoint: 'https://my-localhost.cloudelements.io',
    environmentName: 'localhost-dev',
    displayName: 'Localhost Development',
};

// SAP Environments
const SAP_SNAPSHOT = {
    skeletorEndpoint: 'https://my.openconnectors.ext.int.sap.hana.ondemand.com',
    backendEndpoint: 'https://api.openconnectors.ext.int.sap.hana.ondemand.com',
    environmentName: 'sap-snapshot',
    displayName: 'SAP Snapshot US',
};

const SAP_EXT_TRIAL = {
    skeletorEndpoint: 'https://my.openconnectors.ext.hanatrial.ondemand.com',
    backendEndpoint: 'https://api.openconnectors.ext.hanatrial.ondemand.com',
    environmentName: 'sap-ext-trial',
    displayName: 'SAP Trial',
};

const SAP_US2_EXT = {
    skeletorEndpoint: 'https://my.openconnectors.us2.ext.hana.ondemand.com',
    backendEndpoint: 'https://api.openconnectors.us2.ext.hana.ondemand.com',
    environmentName: 'sap-us2-ext',
    displayName: 'SAP Production US2',
};

const SAP_US4_EXT = {
    skeletorEndpoint: 'https://my.openconnectors.us4.ext.hana.ondemand.com',
    backendEndpoint: 'https://api.openconnectors.us4.ext.hana.ondemand.com',
    environmentName: 'sap-us4-ext',
    displayName: 'SAP Production US4',
};

const SAP_US10_EXT = {
    skeletorEndpoint: 'https://my.openconnectors.us10.ext.hana.ondemand.com',
    backendEndpoint: 'https://api.openconnectors.us10.ext.hana.ondemand.com',
    environmentName: 'sap-us10-ext',
    displayName: 'SAP Production US10',
};

const SAP_US20_EXT = {
    skeletorEndpoint: 'https://my.openconnectors.us20.ext.hana.ondemand.com',
    backendEndpoint: 'https://api.openconnectors.us20.ext.hana.ondemand.com',
    environmentName: 'sap-us20-ext',
    displayName: 'SAP Production US20',
};

const SAP_US21_EXT = {
    skeletorEndpoint: 'https://my.openconnectors.us21.ext.hana.ondemand.com',
    backendEndpoint: 'https://api.openconnectors.us21.ext.hana.ondemand.com',
    environmentName: 'sap-us21-ext',
    displayName: 'SAP Production US21',
};

const SAP_CA10_EXT = {
    skeletorEndpoint: 'https://my.openconnectors.ca10.ext.hana.ondemand.com',
    backendEndpoint: 'https://api.openconnectors.ca10.ext.hana.ondemand.com',
    environmentName: 'sap-ca10-ext',
    displayName: 'SAP Production CA10',
};

const SAP_BR10_EXT = {
    skeletorEndpoint: 'https://my.openconnectors.br10.ext.hana.ondemand.com',
    backendEndpoint: 'https://api.openconnectors.br10.ext.hana.ondemand.com',
    environmentName: 'sap-br10-ext',
    displayName: 'SAP Production BR10',
};

const SAP_EU_EXT = {
    skeletorEndpoint: 'https://my.openconnectors.ext.hana.ondemand.com',
    backendEndpoint: 'https://api.openconnectors.ext.hana.ondemand.com',
    environmentName: 'sap-eu-ext',
    displayName: 'SAP Production EU',
};

const SAP_EU2_EXT = {
    skeletorEndpoint: 'https://my.openconnectors.eu2.ext.hana.ondemand.com',
    backendEndpoint: 'https://api.openconnectors.eu2.ext.hana.ondemand.com',
    environmentName: 'sap-eu2-ext',
    displayName: 'SAP Production EU2',
};

const SAP_EU3_EXT = {
    skeletorEndpoint: 'https://my.openconnectors.eu3.ext.hana.ondemand.com',
    backendEndpoint: 'https://api.openconnectors.eu3.ext.hana.ondemand.com',
    environmentName: 'sap-eu3-ext',
    displayName: 'SAP Production EU3',
};

const SAP_EU10_EXT = {
    skeletorEndpoint: 'https://my.openconnectors.eu10.ext.hana.ondemand.com',
    backendEndpoint: 'https://api.openconnectors.eu10.ext.hana.ondemand.com',
    environmentName: 'sap-eu10-ext',
    displayName: 'SAP Production EU10',
};

const SAP_EU11_EXT = {
    skeletorEndpoint: 'https://my.openconnectors.eu11.ext.hana.ondemand.com',
    backendEndpoint: 'https://api.openconnectors.eu11.ext.hana.ondemand.com',
    environmentName: 'sap-eu11-ext',
    displayName: 'SAP Production EU11',
};

const SAP_EU12_EXT = {
    skeletorEndpoint: 'https://my.openconnectors.eu12.ext.hana.ondemand.com',
    backendEndpoint: 'https://api.openconnectors.eu12.ext.hana.ondemand.com',
    environmentName: 'sap-eu12-ext',
    displayName: 'SAP Production EU12',
};

const SAP_EU20_EXT = {
    skeletorEndpoint: 'https://my.openconnectors.eu20.ext.hana.ondemand.com',
    backendEndpoint: 'https://api.openconnectors.eu20.ext.hana.ondemand.com',
    environmentName: 'sap-eu20-ext',
    displayName: 'SAP Production EU20',
};

const SAP_JP10_EXT = {
    skeletorEndpoint: 'https://my.openconnectors.jp10.ext.hana.ondemand.com',
    backendEndpoint: 'https://api.openconnectors.jp10.ext.hana.ondemand.com',
    environmentName: 'sap-jp10-ext',
    displayName: 'SAP Production JP10',
};

const SAP_JP20_EXT = {
    skeletorEndpoint: 'https://my.openconnectors.jp20.ext.hana.ondemand.com',
    backendEndpoint: 'https://api.openconnectors.jp20.ext.hana.ondemand.com',
    environmentName: 'sap-jp20-ext',
    displayName: 'SAP Production JP20',
};

const SAP_AP10_EXT = {
    skeletorEndpoint: 'https://my.openconnectors.ap10.ext.hana.ondemand.com',
    backendEndpoint: 'https://api.openconnectors.ap10.ext.hana.ondemand.com',
    environmentName: 'sap-ap10-ext',
    displayName: 'SAP Production AP10',
};

const SAP_AP10S_EXT = {
    skeletorEndpoint: 'https://my.openconnectors.ap10s.ext.hana.ondemand.com',
    backendEndpoint: 'https://api.openconnectors.ap10s.ext.hana.ondemand.com',
    environmentName: 'sap-ap10s-ext',
    displayName: 'SAP Production AP10S',
};

const SAP_AP11_EXT = {
    skeletorEndpoint: 'https://my.openconnectors.ap11.ext.hana.ondemand.com',
    backendEndpoint: 'https://api.openconnectors.ap11.ext.hana.ondemand.com',
    environmentName: 'sap-ap11-ext',
    displayName: 'SAP Production AP11',
};

const SAP_AP12_EXT = {
    skeletorEndpoint: 'https://my.openconnectors.ap12.ext.hana.ondemand.com',
    backendEndpoint: 'https://api.openconnectors.ap12.ext.hana.ondemand.com',
    environmentName: 'sap-ap12-ext',
    displayName: 'SAP Production AP12',
};

const SAP_AP21_EXT = {
    skeletorEndpoint: 'https://my.openconnectors.ap21.ext.hana.ondemand.com',
    backendEndpoint: 'https://api.openconnectors.ap21.ext.hana.ondemand.com',
    tag: 'sap-ap21-ext',
    environmentName: 'sap-ap21-ext',
    displayName: 'SAP Production AP21',
};

const SAP_TRIAL_AP21_EXT = {
    skeletorEndpoint: 'https://my.openconnectors.trial.ap21.ext.hana.ondemand.com',
    backendEndpoint: 'https://api.openconnectors.trial.ap21.ext.hana.ondemand.com',
    environmentName: 'sap-trial-ap21-ext',
    displayName: 'SAP Trial AP21',
};

const SAP_TRIAL_EU10_EXT = {
    skeletorEndpoint: 'https://my.openconnectors.trial.eu10.ext.hana.ondemand.com',
    backendEndpoint: 'https://api.openconnectors.trial.eu10.ext.hana.ondemand.com',
    environmentName: 'sap-trial-eu10-ext',
    displayName: 'SAP Trial EU10',
};

const SAP_TRIAL_EU20_EXT = {
    skeletorEndpoint: 'https://my.openconnectors.trial.eu20.ext.hana.ondemand.com',
    backendEndpoint: 'https://api.openconnectors.trial.eu20.ext.hana.ondemand.com',
    environmentName: 'sap-trial-eu20-ext',
    displayName: 'SAP Trial EU20',
};

const SAP_TRIAL_US30_EXT = {
    skeletorEndpoint: 'https://my.openconnectors.trial.us30.ext.hana.ondemand.com',
    backendEndpoint: 'https://api.openconnectors.trial.us30.ext.hana.ondemand.com',
    environmentName: 'sap-trial-us30-ext',
    displayName: 'SAP Trial US30',
};

const SAP_TRIAL_US10_EXT = {
    skeletorEndpoint: 'https://my.openconnectors.trial.us10.ext.hana.ondemand.com',
    backendEndpoint: 'https://api.openconnectors.trial.us10.ext.hana.ondemand.com',
    environmentName: 'sap-trial-us10-ext',
    displayName: 'SAP Trial US10',
};

// IBM Environments
const IBM_BLUEMIX = {
    skeletorEndpoint: 'https://my-ibm.cloud-elements.com',
    backendEndpoint: 'https://ibm.cloud-elements.com',
    environmentName: 'ibm-bluemix',
    displayName: 'IBM BLUEMIX',
};

// Sugar Integrate Environments
const SUGAR_STAGING_US = {
    skeletorEndpoint: 'https://us-staging.integrate.sugarapps.com',
    backendEndpoint: 'https://api-us-staging.integrate.sugarapps.com',
    environmentName: 'sugar-us-staging',
    displayName: 'SUGAR STAGING US',
};

const SUGAR_PRODUCTION_US = {
    skeletorEndpoint: 'https://us.integrate.sugarapps.com',
    backendEndpoint: 'https://api-us.integrate.sugarapps.com',
    environmentName: 'sugar-us-production',
    displayName: 'SUGAR PRODUCTION US',
};

const SUGAR_PRODUCTION_IE = {
    skeletorEndpoint: 'https://ie.integrate.sugarapps.com',
    backendEndpoint: 'https://api-ie.integrate.sugarapps.com',
    environmentName: 'sugar-ie-production',
    displayName: 'SUGAR PRODUCTION IE',
};

const SUGAR_PRODUCTION_AU = {
    skeletorEndpoint: 'https://au.integrate.sugarapps.com',
    backendEndpoint: 'https://api-au.integrate.sugarapps.com',
    environmentName: 'sugar-au-production',
    displayName: 'SUGAR PRODUCTION AU',
};

// Axway Environments
const AXWAY_TEST_STAGING = {
    skeletorEndpoint: 'https://sandbox-ib.platform.axwaytest.net',
    backendEndpoint: 'https://staging.cloud-elements.com',
    environmentName: 'axway-test-staging',
    displayName: 'AXWAY TEST STAGING',
};
const AXWAY_STAGING = {
    skeletorEndpoint: 'https://sandbox-ib.platform.axway.com',
    backendEndpoint: 'https://staging.cloud-elements.com',
    environmentName: 'axway-staging',
    displayName: 'AXWAY STAGING ',
};
const AXWAY_TEST_STAGING_US = {
    skeletorEndpoint: 'https://sandbox-ib.us.axwaytest.net',
    backendEndpoint: 'https://staging.cloud-elements.com',
    environmentName: 'axway-test-staging-us',
    displayName: 'AXWAY TEST STAGING_US ',
};
const AXWAY_TEST_STAGING_US2 = {
    skeletorEndpoint: 'https://sandbox-ib.us-2.axwaytest.net',
    backendEndpoint: 'https://staging.cloud-elements.com',
    environmentName: 'axway-test-staging-us2',
    displayName: 'AXWAY TEST STAGING US2 ',
};
const AXWAY_STAGING_US = {
    skeletorEndpoint: 'https://sandbox-ib.us.axway.com',
    backendEndpoint: 'https://staging.cloud-elements.com',
    environmentName: 'axway-staging-us',
    displayName: 'AXWAY STAGING US ',
};
const AXWAY_STAGING_US2 = {
    skeletorEndpoint: 'https://sandbox-ib.us-2.axway.com',
    backendEndpoint: 'https://staging.cloud-elements.com',
    environmentName: 'axway-staging-us2',
    displayName: 'AXWAY STAGING US2 ',
};
const AXWAY_TEST_PRODUCTION = {
    skeletorEndpoint: 'https://ib.platform.axwaytest.net',
    backendEndpoint: 'https://api.cloud-elements.com',
    environmentName: 'axway-test-production',
    displayName: 'AXWAY TEST PRODUCTION ',
};
const AXWAY_PRODUCTION = {
    skeletorEndpoint: 'https://ib.platform.axway.com',
    backendEndpoint: 'https://api.cloud-elements.com',
    environmentName: 'axway-production',
    displayName: 'AXWAY PRODUCTION ',
};
const AXWAY_TEST_PRODUCTION_US = {
    skeletorEndpoint: 'https://ib.us.axwaytest.net',
    backendEndpoint: 'https://api.cloud-elements.com',
    environmentName: 'axway-test-production-us',
    displayName: 'AXWAY TEST PRODUCTION US ',
};
const AXWAY_PRODUCTION_US = {
    skeletorEndpoint: 'https://ib.us.axway.com',
    backendEndpoint: 'https://api.cloud-elements.com',
    environmentName: 'axway-production-us',
    displayName: 'AXWAY PRODUCTION US ',
};
const AXWAY_TEST_PRODUCTION_EU = {
    skeletorEndpoint: 'https://ib.eu.axwaytest.net',
    backendEndpoint: 'https://api.cloud-elements.co.uk',
    environmentName: 'axway-test-production-eu',
    displayName: 'AXWAY TEST PRODUCTION EU ',
};
const AXWAY_PRODUCTION_EU = {
    skeletorEndpoint: 'https://ib.eu.axway.com',
    backendEndpoint: 'https://api.cloud-elements.co.uk',
    environmentName: 'axway-production-eu',
    displayName: 'AXWAY PRODUCTION EU',
};

const environments = {
    CE_PRODUCTION_US,
    CE_PRODUCTION_UK,
    CE_STAGING_US,
    CE_PRODUCTION_AP,
    CE_SNAP0_US,
    CE_SNAPSHOT_US,
    CE_STAGE0_US,
    CE_USWA_US,
    CE_EUNP_EU,
    LOCAL,
    LOCAL_DEV,
    SAP_SNAPSHOT,
    SAP_EXT_TRIAL,
    SAP_US2_EXT,
    SAP_US4_EXT,
    SAP_US10_EXT,
    SAP_US20_EXT,
    SAP_US21_EXT,
    SAP_CA10_EXT,
    SAP_BR10_EXT,
    SAP_EU_EXT,
    SAP_EU2_EXT,
    SAP_EU3_EXT,
    SAP_EU10_EXT,
    SAP_EU11_EXT,
    SAP_EU12_EXT,
    SAP_EU20_EXT,
    SAP_JP10_EXT,
    SAP_JP20_EXT,
    SAP_AP10_EXT,
    SAP_AP11_EXT,
    SAP_AP12_EXT,
    SAP_AP21_EXT,
    SAP_TRIAL_AP21_EXT,
    SAP_TRIAL_EU10_EXT,
    SAP_TRIAL_EU20_EXT,
    SAP_TRIAL_US30_EXT,
    SAP_TRIAL_US10_EXT,
    IBM_BLUEMIX,
    SUGAR_STAGING_US,
    SUGAR_PRODUCTION_US,
    SUGAR_PRODUCTION_IE,
    SUGAR_PRODUCTION_AU,
    AXWAY_TEST_STAGING,
    AXWAY_STAGING,
    AXWAY_TEST_STAGING_US,
    AXWAY_TEST_STAGING_US2,
    AXWAY_STAGING_US,
    AXWAY_STAGING_US2,
    AXWAY_TEST_PRODUCTION,
    AXWAY_PRODUCTION,
    AXWAY_TEST_PRODUCTION_US,
    AXWAY_PRODUCTION_US,
    AXWAY_TEST_PRODUCTION_EU,
    AXWAY_PRODUCTION_EU,
};