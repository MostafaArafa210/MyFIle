/* eslint-disable no-native-reassign */
/* eslint-disable no-global-assign */
// process gets injected here by webpack so it can be referenced in this file
// process is referenced without the env subobject
// Examples: proccess.SOBA_PORT instead of process.SOBA_PORT

// Set the env variables based on the host name
switch (window.location.hostname) {
    // Cloud Element Envs
    case 'my.cloudelements.io':
    case 'auth.cloudelements.io':
        process = {
            ...process,
            SKELETOR_ENV: 'production',
            SOBA_ENV: 'production',
            ENVIRONMENT_TYPE: 'CE',
        };
        break;
    case 'my.cloudelements.co.uk':
        process = {
            ...process,
            SKELETOR_ENV: 'production-uk',
            SOBA_ENV: 'production-uk',
            ENVIRONMENT_TYPE: 'CE',
        };
        break;
    case 'my-staging.cloudelements.io':
        process = {
            ...process,
            SKELETOR_ENV: 'staging',
            SOBA_ENV: 'staging',
            ENVIRONMENT_TYPE: 'CE',
        };
        break;
    case 'my.stage0.cloudelements.io':
        process = {
            ...process,
            SKELETOR_ENV: 'stage0',
            SOBA_ENV: 'stage0',
            ENVIRONMENT_TYPE: 'CE',
        };
        break;
    case 'my.es-euwest-stage-0.aws-euws.cloudelements.app':
    case 'auth.es-euwest-stage-0.aws-euws.cloudelements.app':
        process = {
            ...process,
            SKELETOR_ENV: 'es-euwest-stage-0',
            SOBA_ENV: 'es-euwest-stage-0',
            ENVIRONMENT_TYPE: 'CE',
        };
        break;
    case 'my.es-uswest-alpha-0.aws-uswa.cloudelements.app':
    case 'auth.es-uswest-alpha-0.aws-uswa.cloudelements.app':
        process = {
            ...process,
            SKELETOR_ENV: 'es-uswest-alpha-0',
            SOBA_ENV: 'es-uswest-alpha-0',
            ENVIRONMENT_TYPE: 'CE',
        };
        break;
    case 'my.apac.cloudelements.io':
        process = {
            ...process,
            SKELETOR_ENV: 'apac0',
            SOBA_ENV: 'apac0',
            ENVIRONMENT_TYPE: 'CE',
        };
        break;
    case 'my.es-eunorth-prod-0.aws-eunp.cloudelements.app':
    case 'auth.es-eunorth-prod-0.aws-eunp.cloudelements.app':
        process = {
            ...process,
            SKELETOR_ENV: 'es-eunorth-prod-0',
            SOBA_ENV: 'es-eunorth-prod-0',
            ENVIRONMENT_TYPE: 'CE',
        };
        break;
    case 'my.es-useast-prod-0.aws-usep.cloudelements.app':
    case 'auth.es-useast-prod-0.aws-usep.cloudelements.app':
        process = {
            ...process,
            SKELETOR_ENV: 'es-useast-prod-0',
            SOBA_ENV: 'es-useast-prod-0',
            ENVIRONMENT_TYPE: 'CE',
        };
        break;
    case 'my.es-jpeast-prod-0.aws-jpep.cloudelements.app':
    case 'auth.es-jpeast-prod-0.aws-jpep.cloudelements.app':
        process = {
            ...process,
            SKELETOR_ENV: 'es-jpeast-prod-0',
            SOBA_ENV: 'es-jpeast-prod-0',
            ENVIRONMENT_TYPE: 'CE',
        };
        break;
    case 'my.es-aueast-prod-0.aws-auep.cloudelements.app':
    case 'auth.es-aueast-prod-0.aws-auep.cloudelements.app':
        process = {
            ...process,
            SKELETOR_ENV: 'es-aueast-prod-0',
            SOBA_ENV: 'es-aueast-prod-0',
            ENVIRONMENT_TYPE: 'CE',
        };
        break;
    case 'my.es-apacsoutheast-prod-0.aws-apsep.cloudelements.app':
    case 'auth.es-apacsoutheast-prod-0.aws-apsep.cloudelements.app':
        process = {
            ...process,
            SKELETOR_ENV: 'es-apacsoutheast-prod-0',
            SOBA_ENV: 'es-apacsoutheast-prod-0',
            ENVIRONMENT_TYPE: 'CE',
        };
        break;
    case 'my-snapshot.cloudelements.io':
        process = {
            ...process,
            SKELETOR_ENV: 'snapshot',
            SOBA_ENV: 'snapshot',
            ENVIRONMENT_TYPE: 'CE',
        };
        break;
    case 'my.snap0.cloudelements.io':
        process = {
            ...process,
            SKELETOR_ENV: 'snap0',
            SOBA_ENV: 'snap0',
            ENVIRONMENT_TYPE: 'CE',
        };
        break;
    case 'my-localhost.cloudelements.io':
        process = {
            ...process,
            SKELETOR_ENV: 'dev-localhost',
            SOBA_ENV: 'localhost',
            ENVIRONMENT_TYPE: 'CE',
        };
        break;
        // IBM Environments
    case 'my-ibm.cloud-elements.com':
        process = {
            ...process,
            SKELETOR_ENV: 'ibm-bluemix',
            SOBA_ENV: 'ibm-bluemix',
            ENVIRONMENT_TYPE: 'IBM',
        };
        break;
        // SAP Environments
    case 'my.openconnectors.ext.int.sap.hana.ondemand.com':
        process = {
            ...process,
            SKELETOR_ENV: 'sap-snapshot',
            SOBA_ENV: 'sap-snapshot',
            ENVIRONMENT_TYPE: 'SAP',
        };
        break;
    case 'my.openconnectors.ext.hanatrial.ondemand.com':
        process = {
            ...process,
            SKELETOR_ENV: 'sap-ext-trial',
            SOBA_ENV: 'sap-ext-trial',
            ENVIRONMENT_TYPE: 'SAP',
        };
        break;
    case 'my.openconnectors.us2.ext.hana.ondemand.com':
        process = {
            ...process,
            SKELETOR_ENV: 'sap-us2-ext',
            SOBA_ENV: 'sap-us2-ext',
            ENVIRONMENT_TYPE: 'SAP',
        };
        break;
    case 'my.openconnectors.us4.ext.hana.ondemand.com':
        process = {
            ...process,
            SKELETOR_ENV: 'sap-us4-ext',
            SOBA_ENV: 'sap-us4-ext',
            ENVIRONMENT_TYPE: 'SAP',
        };
        break;
    case 'my.openconnectors.us10.ext.hana.ondemand.com':
        process = {
            ...process,
            SKELETOR_ENV: 'sap-us10-ext',
            SOBA_ENV: 'sap-us10-ext',
            ENVIRONMENT_TYPE: 'SAP',
        };
        break;
    case 'my.openconnectors.us20.ext.hana.ondemand.com':
        process = {
            ...process,
            SKELETOR_ENV: 'sap-us20-ext',
            SOBA_ENV: 'sap-us20-ext',
            ENVIRONMENT_TYPE: 'SAP',
        };
        break;
    case 'my.openconnectors.us21.ext.hana.ondemand.com':
        process = {
            ...process,
            SKELETOR_ENV: 'sap-us21-ext',
            SOBA_ENV: 'sap-us21-ext',
            ENVIRONMENT_TYPE: 'SAP',
        };
        break;
    case 'my.openconnectors.us30.ext.hana.ondemand.com':
        process = {
            ...process,
            SKELETOR_ENV: 'sap-us30-ext',
            SOBA_ENV: 'sap-us30-ext',
            ENVIRONMENT_TYPE: 'SAP',
        };
        break;
    case 'my.openconnectors.ca10.ext.hana.ondemand.com':
        process = {
            ...process,
            SKELETOR_ENV: 'sap-ca10-ext',
            SOBA_ENV: 'sap-ca10-ext',
            ENVIRONMENT_TYPE: 'SAP',
        };
        break;
    case 'my.openconnectors.br10.ext.hana.ondemand.com':
        process = {
            ...process,
            SKELETOR_ENV: 'sap-br10-ext',
            SOBA_ENV: 'sap-br10-ext',
            ENVIRONMENT_TYPE: 'SAP',
        };
        break;
    case 'my.openconnectors.ext.hana.ondemand.com':
        process = {
            ...process,
            SKELETOR_ENV: 'sap-eu-ext',
            SOBA_ENV: 'sap-eu-ext',
            ENVIRONMENT_TYPE: 'SAP',
        };
        break;
    case 'my.openconnectors.eu2.ext.hana.ondemand.com':
        process = {
            ...process,
            SKELETOR_ENV: 'sap-eu2-ext',
            SOBA_ENV: 'sap-eu2-ext',
            ENVIRONMENT_TYPE: 'SAP',
        };
        break;
    case 'my.openconnectors.eu3.ext.hana.ondemand.com':
        process = {
            ...process,
            SKELETOR_ENV: 'sap-eu3-ext',
            SOBA_ENV: 'sap-eu3-ext',
            ENVIRONMENT_TYPE: 'SAP',
        };
        break;
    case 'my.openconnectors.eu10.ext.hana.ondemand.com':
        process = {
            ...process,
            SKELETOR_ENV: 'sap-eu10-ext',
            SOBA_ENV: 'sap-eu10-ext',
            ENVIRONMENT_TYPE: 'SAP',
        };
        break;
    case 'my.openconnectors.eu12.ext.hana.ondemand.com':
        process = {
            ...process,
            SKELETOR_ENV: 'sap-eu12-ext',
            SOBA_ENV: 'sap-eu12-ext',
            ENVIRONMENT_TYPE: 'SAP',
        };
        break;
    case 'my.openconnectors.eu11.ext.hana.ondemand.com':
        process = {
            ...process,
            SKELETOR_ENV: 'sap-eu11-ext',
            SOBA_ENV: 'sap-eu11-ext',
            ENVIRONMENT_TYPE: 'SAP',
        };
        break;
    case 'my.openconnectors.eu20.ext.hana.ondemand.com':
        process = {
            ...process,
            SKELETOR_ENV: 'sap-eu20-ext',
            SOBA_ENV: 'sap-eu20-ext',
            ENVIRONMENT_TYPE: 'SAP',
        };
        break;
    case 'my.openconnectors.eu30.ext.hana.ondemand.com':
        process = {
            ...process,
            SKELETOR_ENV: 'sap-eu30-ext',
            SOBA_ENV: 'sap-eu30-ext',
            ENVIRONMENT_TYPE: 'SAP',
        };
        break;
    case 'my.openconnectors.jp20.ext.hana.ondemand.com':
        process = {
            ...process,
            SKELETOR_ENV: 'sap-jp20-ext',
            SOBA_ENV: 'sap-jp20-ext',
            ENVIRONMENT_TYPE: 'SAP',
        };
        break;
    case 'my.openconnectors.jp10.ext.hana.ondemand.com':
        process = {
            ...process,
            SKELETOR_ENV: 'sap-jp10-ext',
            SOBA_ENV: 'sap-jp10-ext',
            ENVIRONMENT_TYPE: 'SAP',
        };
        break;
    case 'my.openconnectors.ap10.ext.hana.ondemand.com':
        process = {
            ...process,
            SKELETOR_ENV: 'sap-ap10-ext',
            SOBA_ENV: 'sap-ap10-ext',
            ENVIRONMENT_TYPE: 'SAP',
        };
        break;
    case 'my.openconnectors.ap10s.ext.hana.ondemand.com':
        process = {
            ...process,
            SKELETOR_ENV: 'sap-ap10s-ext',
            SOBA_ENV: 'sap-ap10s-ext',
            ENVIRONMENT_TYPE: 'SAP',
        };
        break;
    case 'my.openconnectors.ap11.ext.hana.ondemand.com':
        process = {
            ...process,
            SKELETOR_ENV: 'sap-ap11-ext',
            SOBA_ENV: 'sap-ap11-ext',
            ENVIRONMENT_TYPE: 'SAP',
        };
        break;
    case 'my.openconnectors.ap12.ext.hana.ondemand.com':
        process = {
            ...process,
            SKELETOR_ENV: 'sap-ap12-ext',
            SOBA_ENV: 'sap-ap12-ext',
            ENVIRONMENT_TYPE: 'SAP',
        };
        break;
    case 'my.openconnectors.ap20.ext.hana.ondemand.com':
        process = {
            ...process,
            SKELETOR_ENV: 'sap-ap20-ext',
            SOBA_ENV: 'sap-ap20-ext',
            ENVIRONMENT_TYPE: 'SAP',
        };
        break;
    case 'my.openconnectors.ap21.ext.hana.ondemand.com':
        process = {
            ...process,
            SKELETOR_ENV: 'sap-ap21-ext',
            SOBA_ENV: 'sap-ap21-ext',
            ENVIRONMENT_TYPE: 'SAP',
        };
        break;
    case 'my.openconnectors.in30.ext.hana.ondemand.com':
        process = {
            ...process,
            SKELETOR_ENV: 'sap-in30-ext',
            SOBA_ENV: 'sap-in30-ext',
            ENVIRONMENT_TYPE: 'SAP',
        };
        break;
    case 'my.openconnectors.trial.ap21.ext.hana.ondemand.com':
        process = {
            ...process,
            SKELETOR_ENV: 'sap-trial-ap21-ext',
            SOBA_ENV: 'sap-trial-ap21-ext',
            ENVIRONMENT_TYPE: 'SAP',
        };
        break;
    case 'my.openconnectors.trial.eu10.ext.hana.ondemand.com':
        process = {
            ...process,
            SKELETOR_ENV: 'sap-trial-eu10-ext',
            SOBA_ENV: 'sap-trial-eu10-ext',
            ENVIRONMENT_TYPE: 'SAP',
        };
        break;
    case 'my.openconnectors.trial.eu20.ext.hana.ondemand.com':
        process = {
            ...process,
            SKELETOR_ENV: 'sap-trial-eu20-ext',
            SOBA_ENV: 'sap-trial-eu20-ext',
            ENVIRONMENT_TYPE: 'SAP',
        };
        break;
    case 'my.openconnectors.trial.us30.ext.hana.ondemand.com':
        process = {
            ...process,
            SKELETOR_ENV: 'sap-trial-us30-ext',
            SOBA_ENV: 'sap-trial-us30-ext',
            ENVIRONMENT_TYPE: 'SAP',
        };
        break;
    case 'my.openconnectors.trial.us10.ext.hana.ondemand.com':
        process = {
            ...process,
            SKELETOR_ENV: 'sap-trial-us10-ext',
            SOBA_ENV: 'sap-trial-us10-ext',
            ENVIRONMENT_TYPE: 'SAP',
        };
        break;
        // Axway Staging Environments
    case 'sandbox-ib.platform.axwaytest.net':
        process = {
            ...process,
            SKELETOR_ENV: 'staging',
            SOBA_ENV: 'staging',
            ENVIRONMENT_TYPE: 'AXWAY',
        };
        break;
    case 'sandbox-ib.platform.axway.com':
        process = {
            ...process,
            SKELETOR_ENV: 'staging',
            SOBA_ENV: 'staging',
            ENVIRONMENT_TYPE: 'AXWAY',
        };
        break;
        // Axway Staging New
    case 'sandbox-ib.us.axwaytest.net':
        process = {
            ...process,
            SKELETOR_ENV: 'staging',
            SOBA_ENV: 'staging',
            ENVIRONMENT_TYPE: 'AXWAY',
        };
        break;
    case 'sandbox-ib.us-2.axwaytest.net':
        process = {
            ...process,
            SKELETOR_ENV: 'staging',
            SOBA_ENV: 'staging',
            ENVIRONMENT_TYPE: 'AXWAY',
        };
        break;
    case 'sandbox-ib.us.axway.com':
        process = {
            ...process,
            SKELETOR_ENV: 'staging',
            SOBA_ENV: 'staging',
            ENVIRONMENT_TYPE: 'AXWAY',
        };
        break;
    case 'sandbox-ib.us-2.axway.com':
        process = {
            ...process,
            SKELETOR_ENV: 'staging',
            SOBA_ENV: 'staging',
            ENVIRONMENT_TYPE: 'AXWAY',
        };
        break;
        // Axway US Production Environments
    case 'ib.platform.axwaytest.net':
        process = {
            ...process,
            SKELETOR_ENV: 'production',
            SOBA_ENV: 'production',
            ENVIRONMENT_TYPE: 'AXWAY',
        };
        break;
    case 'ib.platform.axway.com':
        process = {
            ...process,
            SKELETOR_ENV: 'production',
            SOBA_ENV: 'production',
            ENVIRONMENT_TYPE: 'AXWAY',
        };
        break;
    case 'ib.us.axwaytest.net':
        process = {
            ...process,
            SKELETOR_ENV: 'production',
            SOBA_ENV: 'production',
            ENVIRONMENT_TYPE: 'AXWAY',
        };
        break;
    case 'ib.us.axway.com':
        process = {
            ...process,
            SKELETOR_ENV: 'production',
            SOBA_ENV: 'production',
            ENVIRONMENT_TYPE: 'AXWAY',
        };
        break;
        // Axway EU Production Environments
    case 'ib.eu.axwaytest.net':
        process = {
            ...process,
            SKELETOR_ENV: 'production-uk',
            SOBA_ENV: 'production-uk',
            ENVIRONMENT_TYPE: 'AXWAY',
        };
        break;
    case 'ib.eu.axway.com':
        process = {
            ...process,
            SKELETOR_ENV: 'production-uk',
            SOBA_ENV: 'production-uk',
            ENVIRONMENT_TYPE: 'AXWAY',
        };
        break;
        // Sugar Environments
    case 'us-staging.integrate.sugarapps.com':
        process = {
            ...process,
            SKELETOR_ENV: 'sugar-us-staging',
            SOBA_ENV: 'sugar-us-staging',
            ENVIRONMENT_TYPE: 'SUGAR',
        };
        break;
    case 'us.integrate.sugarapps.com':
        process = {
            ...process,
            SKELETOR_ENV: 'sugar-us-production',
            SOBA_ENV: 'sugar-us-production',
            ENVIRONMENT_TYPE: 'SUGAR',
        };
        break;
    case 'ie.integrate.sugarapps.com':
        process = {
            ...process,
            SKELETOR_ENV: 'sugar-ie-production',
            SOBA_ENV: 'sugar-ie-production',
            ENVIRONMENT_TYPE: 'SUGAR',
        };
        break;
    case 'au.integrate.sugarapps.com':
        process = {
            ...process,
            SKELETOR_ENV: 'sugar-au-production',
            SOBA_ENV: 'sugar-au-production',
            ENVIRONMENT_TYPE: 'SUGAR',
        };
        break;
    default:
        process = {
            ...process,
            ENVIRONMENT_TYPE: 'CE',
        };
        break;
}